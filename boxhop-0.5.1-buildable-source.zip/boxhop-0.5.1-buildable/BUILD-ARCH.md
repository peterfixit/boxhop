# Build BoxHop 0.5.1 on Arch Linux

This is the buildable checkpoint derived from the last working BoxHop FTP/SSH/RDP/logging code plus the 0.5 UI/icon/streaming improvements.

## Dependencies

```bash
sudo pacman -S --needed base-devel rust gtk4 vte4 openssh freerdp gnupg
```

`gnupg` is required by this checkpoint's encrypted credential vault. It is explicit, not hidden.

## Run from source

```bash
chmod +x run-from-source.sh scripts/*.sh
./run-from-source.sh
```

## Release build

```bash
cargo build --release
./target/release/boxhop
```

## If compilation fails

Run:

```bash
cargo build 2>&1 | tee boxhop-build.log
```

and provide `boxhop-build.log`.
