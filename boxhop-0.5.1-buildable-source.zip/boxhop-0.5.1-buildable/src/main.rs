use anyhow::{Context, Result};
use directories::ProjectDirs;
use gtk::gdk;
use gtk::prelude::*;
use gtk::{
    Application, ApplicationWindow, Box as GtkBox, Button, CheckButton, Dialog, Entry, Grid, Image, Label,
    ListBox, ListBoxRow, Orientation, Paned, ResponseType, ScrolledWindow, Stack, TextView,
};
use serde::{Deserialize, Serialize};
use std::cell::RefCell;
use std::fs::{self, File, OpenOptions};
use std::io::{BufRead, BufReader, Read, Write};
use std::net::{TcpStream, ToSocketAddrs, UdpSocket};
use std::os::unix::fs::{OpenOptionsExt, PermissionsExt};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::backtrace::Backtrace;
use std::rc::Rc;
use std::sync::mpsc::{self, TryRecvError};
use std::thread;
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use uuid::Uuid;
use vte4::prelude::*;
use vte4::Terminal;

const APP_ID: &str = "io.pmhs.boxhop";
const APP_VERSION: &str = env!("CARGO_PKG_VERSION");
const RUNTIME_LOG_MAX_BYTES: u64 = 5 * 1024 * 1024;
const CRASH_LOG_MAX_BYTES: u64 = 2 * 1024 * 1024;
const PACKAGE_S2K_COUNT: &str = "1048576";
const PASSWORD_WRAP_S2K_COUNT: &str = "65011712";

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
struct Asset {
    id: Uuid,
    name: String,
    host: String,
    username: String,
    ssh_port: u16,
    transfer_port: u16,
    ftp_username: String,
    ftp_port: u16,
    mac: String,
    local_path: String,
    remote_path: String,
    auto_connect: bool,
    save_username: bool,
    rdp_username: String,
    rdp_domain: String,
    rdp_port: u16,
    rdp_dynamic_resolution: bool,
    rdp_clipboard: bool,
    rdp_tofu: bool,
}

impl Default for Asset {
    fn default() -> Self {
        Self {
            id: Uuid::new_v4(),
            name: "New asset".into(),
            host: String::new(),
            username: String::new(),
            ssh_port: 22,
            transfer_port: 22,
            ftp_username: String::new(),
            ftp_port: 21,
            mac: String::new(),
            local_path: String::new(),
            remote_path: String::new(),
            auto_connect: false,
            save_username: true,
            rdp_username: String::new(),
            rdp_domain: String::new(),
            rdp_port: 3389,
            rdp_dynamic_resolution: true,
            rdp_clipboard: true,
            rdp_tofu: true,
        }
    }
}

#[derive(Clone)]
struct AssetEditor {
    name: Entry,
    host: Entry,
    mac: Entry,
    username: Entry,
    ssh_password: Entry,
    ssh_port: Entry,
    transfer_port: Entry,
    ftp_username: Entry,
    ftp_password: Entry,
    ftp_port: Entry,
    local_path: Entry,
    remote_path: Entry,
    auto_connect: CheckButton,
    rdp_username: Entry,
    rdp_password: Entry,
    rdp_domain: Entry,
    rdp_port: Entry,
    rdp_dynamic_resolution: CheckButton,
    rdp_clipboard: CheckButton,
    rdp_tofu: CheckButton,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
struct AssetSecrets {
    ssh_password: String,
    ftp_password: String,
    rdp_password: String,
}

#[derive(Debug, Clone)]
struct FileItem {
    name: String,
    is_dir: bool,
}

#[derive(Debug, Clone)]
struct RemoteListing {
    path: String,
    items: Vec<FileItem>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum RemoteProtocol {
    Sftp,
    Ftp,
}

impl RemoteProtocol {
    fn label(self) -> &'static str {
        match self {
            Self::Sftp => "SFTP",
            Self::Ftp => "FTP",
        }
    }
}

fn local_home() -> String {
    std::env::var("HOME").unwrap_or_else(|_| "/".into())
}

fn list_local(path: &str) -> Result<Vec<FileItem>> {
    let path = if path.trim().is_empty() { local_home() } else { path.to_string() };
    let mut items = Vec::new();
    for entry in fs::read_dir(&path).with_context(|| format!("Unable to read local directory {path}"))? {
        let entry = entry?;
        let file_type = entry.file_type()?;
        items.push(FileItem {
            name: entry.file_name().to_string_lossy().into_owned(),
            is_dir: file_type.is_dir(),
        });
    }
    items.sort_by(|a, b| b.is_dir.cmp(&a.is_dir).then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase())));
    Ok(items)
}

fn sftp_quote(value: &str) -> String {
    format!("\"{}\"", value.replace('\\', "\\\\").replace('"', "\\\""))
}

fn sftp_batch(asset: &Asset, commands: &str) -> Result<String> {
    anyhow::ensure!(!asset.host.trim().is_empty(), "Host/IP is not configured");
    let sftp = find_program(&["sftp"]).context(
        "OpenSSH sftp client not found. Native Arch development: sudo pacman -S openssh. The final Flatpak will bundle its transfer engine.",
    )?;
    let mut child = Command::new(sftp)
        .arg("-q")
        .arg("-b")
        .arg("-")
        .arg("-P")
        .arg(asset.transfer_port.to_string())
        .arg(ssh_target(asset))
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .context("Unable to start sftp")?;

    if let Some(mut stdin) = child.stdin.take() {
        stdin.write_all(commands.as_bytes()).context("Unable to send commands to sftp")?;
    }
    let output = child.wait_with_output().context("Unable to wait for sftp")?;
    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr).trim().to_string();
        anyhow::bail!(if stderr.is_empty() {
            "SFTP failed. Password-interactive authentication is not available in the dual-pane browser yet; use SSH key/agent authentication.".to_string()
        } else {
            stderr
        });
    }
    Ok(String::from_utf8_lossy(&output.stdout).into_owned())
}

fn list_remote_sftp(asset: &Asset, path: &str) -> Result<RemoteListing> {
    let path = if path.trim().is_empty() { "." } else { path };
    let output = sftp_batch(asset, &format!("cd {}\nls -l\nquit\n", sftp_quote(path)))?;
    let mut items = Vec::new();
    for line in output.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with("sftp>") || line.starts_with("Connected to ") {
            continue;
        }
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() < 9 {
            continue;
        }
        let mode = parts[0];
        let name = parts[8..].join(" ");
        if name == "." || name == ".." {
            continue;
        }
        items.push(FileItem { name, is_dir: mode.starts_with('d') });
    }
    items.sort_by(|a, b| b.is_dir.cmp(&a.is_dir).then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase())));
    Ok(RemoteListing { path: path.to_string(), items })
}

fn rebuild_file_list(list: &ListBox, items: &[FileItem]) {
    while let Some(child) = list.first_child() {
        list.remove(&child);
    }
    if items.is_empty() {
        let row = ListBoxRow::new();
        row.set_selectable(false);
        row.set_activatable(false);
        let label = Label::new(Some("(empty directory)"));
        label.set_xalign(0.0);
        label.add_css_class("muted");
        label.set_margin_top(12);
        label.set_margin_bottom(12);
        label.set_margin_start(12);
        label.set_margin_end(12);
        row.set_child(Some(&label));
        list.append(&row);
        return;
    }

    for item in items {
        let row = ListBoxRow::new();
        row.add_css_class("file-row");

        let line = GtkBox::new(Orientation::Horizontal, 10);
        line.set_margin_top(6);
        line.set_margin_bottom(6);
        line.set_margin_start(10);
        line.set_margin_end(10);

        let icon_name = if item.is_dir { "folder-symbolic" } else { "text-x-generic-symbolic" };
        let icon = Image::from_icon_name(icon_name);
        icon.set_pixel_size(18);
        icon.add_css_class("file-icon");

        let label = Label::new(Some(&item.name));
        label.set_xalign(0.0);
        label.set_hexpand(true);
        label.set_ellipsize(gtk::pango::EllipsizeMode::End);

        let kind = Label::new(Some(if item.is_dir { "Folder" } else { "File" }));
        kind.add_css_class("file-kind");

        line.append(&icon);
        line.append(&label);
        line.append(&kind);
        row.set_child(Some(&line));
        list.append(&row);
    }
}

fn set_file_list_message(list: &ListBox, text: &str) {
    while let Some(child) = list.first_child() {
        list.remove(&child);
    }
    let row = ListBoxRow::new();
    row.set_selectable(false);
    row.set_activatable(false);
    let label = Label::new(Some(text));
    label.set_xalign(0.0);
    label.add_css_class("muted");
    label.set_margin_top(10);
    label.set_margin_bottom(10);
    label.set_margin_start(10);
    label.set_margin_end(10);
    row.set_child(Some(&label));
    list.append(&row);
}

fn join_remote(base: &str, name: &str) -> String {
    if base.trim().is_empty() || base == "." {
        name.to_string()
    } else if base == "/" {
        format!("/{name}")
    } else {
        format!("{}/{}", base.trim_end_matches('/'), name)
    }
}

fn remote_parent(path: &str) -> String {
    let trimmed = path.trim_end_matches('/');
    if trimmed.is_empty() || trimmed == "." || trimmed == "/" {
        return if trimmed == "/" { "/".into() } else { ".".into() };
    }
    match trimmed.rsplit_once('/') {
        Some(("", _)) => "/".into(),
        Some((parent, _)) => parent.to_string(),
        None => ".".into(),
    }
}

fn sftp_upload(asset: &Asset, local_path: &str, remote_path: &str, item: &FileItem) -> Result<()> {
    let local = PathBuf::from(local_path).join(&item.name);
    let remote = join_remote(remote_path, &item.name);
    let command = if item.is_dir {
        format!("put -r {} {}\nquit\n", sftp_quote(&local.to_string_lossy()), sftp_quote(&remote))
    } else {
        format!("put {} {}\nquit\n", sftp_quote(&local.to_string_lossy()), sftp_quote(&remote))
    };
    sftp_batch(asset, &command)?;
    Ok(())
}

fn sftp_download(asset: &Asset, local_path: &str, remote_path: &str, item: &FileItem) -> Result<()> {
    let local = PathBuf::from(local_path).join(&item.name);
    let remote = join_remote(remote_path, &item.name);
    let command = if item.is_dir {
        format!("get -r {} {}\nquit\n", sftp_quote(&remote), sftp_quote(&local.to_string_lossy()))
    } else {
        format!("get {} {}\nquit\n", sftp_quote(&remote), sftp_quote(&local.to_string_lossy()))
    };
    sftp_batch(asset, &command)?;
    Ok(())
}

fn run_background<T, W, D>(work: W, done: D)
where
    T: Send + 'static,
    W: FnOnce() -> Result<T> + Send + 'static,
    D: FnOnce(std::result::Result<T, String>) + 'static,
{
    let (tx, rx) = mpsc::channel::<std::result::Result<T, String>>();
    thread::spawn(move || {
        let result = work().map_err(|err| format!("{err:#}"));
        let _ = tx.send(result);
    });

    let mut done = Some(done);
    glib::timeout_add_local(Duration::from_millis(40), move || match rx.try_recv() {
        Ok(result) => {
            if let Some(done) = done.take() {
                done(result);
            }
            glib::ControlFlow::Break
        }
        Err(TryRecvError::Empty) => glib::ControlFlow::Continue,
        Err(TryRecvError::Disconnected) => {
            if let Some(done) = done.take() {
                done(Err("Background operation ended unexpectedly".to_string()));
            }
            glib::ControlFlow::Break
        }
    });
}

fn epoch_seconds() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

fn utc_timestamp() -> String {
    // UTC calendar conversion using the proleptic Gregorian calendar. Keeping
    // this in-process avoids adding a timestamp-only runtime dependency.
    let seconds = epoch_seconds() as i64;
    let days = seconds.div_euclid(86_400);
    let day_seconds = seconds.rem_euclid(86_400);
    let hour = day_seconds / 3_600;
    let minute = (day_seconds % 3_600) / 60;
    let second = day_seconds % 60;

    let z = days + 719_468;
    let era = if z >= 0 { z } else { z - 146_096 } / 146_097;
    let doe = z - era * 146_097;
    let yoe = (doe - doe / 1_460 + doe / 36_524 - doe / 146_096) / 365;
    let mut year = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let day = doy - (153 * mp + 2) / 5 + 1;
    let month = mp + if mp < 10 { 3 } else { -9 };
    if month <= 2 {
        year += 1;
    }

    format!("{year:04}-{month:02}-{day:02}T{hour:02}:{minute:02}:{second:02}Z")
}

fn log_dir() -> Result<PathBuf> {
    let base = if let Some(path) = std::env::var_os("XDG_STATE_HOME") {
        PathBuf::from(path)
    } else if let Some(home) = std::env::var_os("HOME") {
        PathBuf::from(home).join(".local/state")
    } else {
        config_dir()?.join("state")
    };
    let path = base.join("boxhop").join("logs");
    fs::create_dir_all(&path)?;
    fs::set_permissions(&path, fs::Permissions::from_mode(0o700))?;
    Ok(path)
}

fn runtime_log_path() -> Result<PathBuf> {
    Ok(log_dir()?.join("boxhop.log"))
}

fn crash_log_path() -> Result<PathBuf> {
    Ok(log_dir()?.join("crash.log"))
}

fn session_marker_path(pid: u32) -> Result<PathBuf> {
    Ok(log_dir()?.join(format!("session-{pid}.running")))
}

fn rotate_log(path: &Path, max_bytes: u64) {
    let Ok(meta) = fs::metadata(path) else { return; };
    if meta.len() <= max_bytes {
        return;
    }
    let backup = PathBuf::from(format!("{}.1", path.display()));
    let _ = fs::remove_file(&backup);
    let _ = fs::rename(path, backup);
}

fn append_log_line(path: &Path, level: &str, message: &str) {
    let Ok(mut file) = OpenOptions::new()
        .create(true)
        .append(true)
        .write(true)
        .mode(0o600)
        .open(path)
    else {
        return;
    };
    let ts = utc_timestamp();
    let pid = std::process::id();
    let mut wrote = false;
    for line in message.lines() {
        let _ = writeln!(file, "[{ts}] [pid:{pid}] [{level}] {line}");
        wrote = true;
    }
    if !wrote {
        let _ = writeln!(file, "[{ts}] [pid:{pid}] [{level}]");
    }
    let _ = file.flush();
    let _ = fs::set_permissions(path, fs::Permissions::from_mode(0o600));
}

fn update_session_marker(level: &str, message: &str) {
    let Ok(path) = session_marker_path(std::process::id()) else { return; };
    let safe_message = message.replace('\n', " | ");
    let marker = format!(
        "BoxHop {APP_VERSION}\npid={}\nlast_update={}\nlast_level={}\nlast_event={}\n",
        std::process::id(),
        utc_timestamp(),
        level,
        safe_message
    );
    if let Ok(mut file) = OpenOptions::new()
        .create(true)
        .truncate(true)
        .write(true)
        .mode(0o600)
        .open(&path)
    {
        let _ = file.write_all(marker.as_bytes());
        let _ = file.flush();
        let _ = fs::set_permissions(path, fs::Permissions::from_mode(0o600));
    }
}

fn log_event(level: &str, message: &str) {
    if let Ok(path) = runtime_log_path() {
        append_log_line(&path, level, message);
    }
    update_session_marker(level, message);
}

fn read_log_tail(path: &Path, max_bytes: usize) -> String {
    let Ok(bytes) = fs::read(path) else {
        return String::new();
    };
    let start = bytes.len().saturating_sub(max_bytes);
    String::from_utf8_lossy(&bytes[start..]).into_owned()
}

fn log_crash(message: &str) {
    if let Ok(path) = crash_log_path() {
        append_log_line(&path, "CRASH", message);
        if let Ok(runtime_path) = runtime_log_path() {
            let recent = read_log_tail(&runtime_path, 64 * 1024);
            if !recent.trim().is_empty() {
                append_log_line(&path, "CONTEXT", "Recent runtime log follows:");
                append_log_line(&path, "CONTEXT", &recent);
            }
        }
    }
}

fn detect_stale_sessions() {
    let Ok(dir) = log_dir() else { return; };
    let Ok(entries) = fs::read_dir(&dir) else { return; };
    let current_pid = std::process::id();
    for entry in entries.flatten() {
        let name = entry.file_name().to_string_lossy().into_owned();
        let Some(pid_text) = name
            .strip_prefix("session-")
            .and_then(|v| v.strip_suffix(".running"))
        else {
            continue;
        };
        let Ok(pid) = pid_text.parse::<u32>() else { continue; };
        if pid == current_pid || Path::new(&format!("/proc/{pid}")).exists() {
            continue;
        }
        let detail = fs::read_to_string(entry.path()).unwrap_or_else(|_| "unknown previous session".into());
        log_crash(&format!(
            "Previous BoxHop session ended without a clean shutdown. Stale session marker: {} ({})",
            name,
            detail.trim()
        ));
        let _ = fs::remove_file(entry.path());
    }
}

fn install_panic_logging() {
    let previous = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |info| {
        let thread = std::thread::current();
        let thread_name = thread.name().unwrap_or("unnamed");
        let backtrace = Backtrace::force_capture();
        log_crash(&format!(
            "Rust panic on thread '{thread_name}': {info}\nBacktrace:\n{backtrace}"
        ));
        previous(info);
    }));
}

fn initialise_logging() {
    if let Ok(path) = runtime_log_path() {
        rotate_log(&path, RUNTIME_LOG_MAX_BYTES);
    }
    if let Ok(path) = crash_log_path() {
        rotate_log(&path, CRASH_LOG_MAX_BYTES);
    }
    detect_stale_sessions();
    update_session_marker("INFO", "initialising logging");
    install_panic_logging();
    log_event("INFO", &format!("BoxHop {APP_VERSION} starting"));
}

fn finish_logging() {
    log_event("INFO", &format!("BoxHop {APP_VERSION} clean shutdown"));
    if let Ok(path) = session_marker_path(std::process::id()) {
        let _ = fs::remove_file(path);
    }
}

fn refresh_log_views(runtime_view: &TextView, crash_view: &TextView) {
    let runtime_text = runtime_log_path()
        .map(|path| read_log_tail(&path, 512 * 1024))
        .unwrap_or_default();
    let crash_text = crash_log_path()
        .map(|path| read_log_tail(&path, 512 * 1024))
        .unwrap_or_default();
    runtime_view.buffer().set_text(if runtime_text.is_empty() {
        "No runtime log entries yet."
    } else {
        &runtime_text
    });
    crash_view.buffer().set_text(if crash_text.is_empty() {
        "No crash records."
    } else {
        &crash_text
    });
}

fn config_dir() -> Result<PathBuf> {
    let dirs = ProjectDirs::from("io", "pmhs", "boxhop").context("Unable to resolve config directory")?;
    let path = dirs.config_dir().to_path_buf();
    fs::create_dir_all(&path)?;
    fs::set_permissions(&path, fs::Permissions::from_mode(0o700))?;
    Ok(path)
}

fn config_path() -> Result<PathBuf> {
    Ok(config_dir()?.join("assets.json"))
}

fn credentials_dir() -> Result<PathBuf> {
    let path = config_dir()?.join("credentials");
    fs::create_dir_all(&path)?;
    fs::set_permissions(&path, fs::Permissions::from_mode(0o700))?;
    Ok(path)
}

fn vault_key_path() -> Result<PathBuf> {
    Ok(credentials_dir()?.join("vault-key.gpg"))
}

fn secret_path(asset_id: Uuid) -> Result<PathBuf> {
    Ok(credentials_dir()?.join(format!("asset-{asset_id}.gpg")))
}

fn vault_exists() -> bool {
    vault_key_path().map(|p| p.is_file()).unwrap_or(false)
}

fn secure_write(path: &Path, data: &[u8]) -> Result<()> {
    let mut file = OpenOptions::new()
        .create(true)
        .truncate(true)
        .write(true)
        .mode(0o600)
        .open(path)?;
    file.write_all(data)?;
    file.sync_all()?;
    fs::set_permissions(path, fs::Permissions::from_mode(0o600))?;
    Ok(())
}

fn random_vault_key() -> Result<String> {
    let mut random = [0u8; 64];
    File::open("/dev/urandom")
        .context("Unable to open the kernel random source")?
        .read_exact(&mut random)
        .context("Unable to generate a vault key")?;
    let mut out = String::with_capacity(random.len() * 2);
    for byte in random {
        out.push_str(&format!("{byte:02x}"));
    }
    Ok(out)
}

fn gpg_home() -> Result<PathBuf> {
    let path = credentials_dir()?.join(".gnupg");
    fs::create_dir_all(&path)?;
    fs::set_permissions(&path, fs::Permissions::from_mode(0o700))?;
    Ok(path)
}

fn gpg_encrypt_file(input: &Path, output: &Path, passphrase: &str, s2k_count: &str) -> Result<()> {
    let gpg = find_program(&["gpg"]).context(
        "GnuPG not found. Native Arch development: sudo pacman -S --needed gnupg. The final Flatpak must bundle this vault engine.",
    )?;
    let mut child = Command::new(gpg)
        .env("GNUPGHOME", gpg_home()?)
        .args([
            "--batch",
            "--yes",
            "--quiet",
            "--no-secmem-warning",
            "--no-autostart",
            "--no-symkey-cache",
            "--pinentry-mode",
            "loopback",
            "--passphrase-fd",
            "0",
            "--symmetric",
            "--cipher-algo",
            "AES256",
            "--compress-algo",
            "none",
            "--s2k-mode",
            "3",
            "--s2k-digest-algo",
            "SHA512",
            "--s2k-count",
            s2k_count,
            "--output",
        ])
        .arg(output)
        .arg("--")
        .arg(input)
        .stdin(Stdio::piped())
        .stdout(Stdio::null())
        .stderr(Stdio::piped())
        .spawn()
        .context("Unable to start GnuPG encryption")?;
    if let Some(mut stdin) = child.stdin.take() {
        stdin.write_all(passphrase.as_bytes())?;
        stdin.write_all(b"\n")?;
    }
    let output_status = child.wait_with_output()?;
    if !output_status.status.success() {
        let stderr = String::from_utf8_lossy(&output_status.stderr).trim().to_string();
        if stderr.is_empty() {
            anyhow::bail!("GnuPG encryption failed");
        }
        anyhow::bail!("{stderr}");
    }
    fs::set_permissions(output, fs::Permissions::from_mode(0o600))?;
    Ok(())
}

fn gpg_decrypt_file(input: &Path, output: &Path, passphrase: &str) -> Result<()> {
    let gpg = find_program(&["gpg"]).context(
        "GnuPG not found. Native Arch development: sudo pacman -S --needed gnupg. The final Flatpak must bundle this vault engine.",
    )?;
    let mut child = Command::new(gpg)
        .env("GNUPGHOME", gpg_home()?)
        .args([
            "--batch",
            "--yes",
            "--quiet",
            "--no-secmem-warning",
            "--no-autostart",
            "--no-symkey-cache",
            "--pinentry-mode",
            "loopback",
            "--passphrase-fd",
            "0",
            "--decrypt",
            "--output",
        ])
        .arg(output)
        .arg("--")
        .arg(input)
        .stdin(Stdio::piped())
        .stdout(Stdio::null())
        .stderr(Stdio::piped())
        .spawn()
        .context("Unable to start GnuPG decryption")?;
    if let Some(mut stdin) = child.stdin.take() {
        stdin.write_all(passphrase.as_bytes())?;
        stdin.write_all(b"\n")?;
    }
    let output_status = child.wait_with_output()?;
    if !output_status.status.success() {
        let _ = fs::remove_file(output);
        anyhow::bail!("Incorrect vault password or damaged credential vault");
    }
    fs::set_permissions(output, fs::Permissions::from_mode(0o600))?;
    Ok(())
}

fn create_vault(master_password: &str) -> Result<String> {
    anyhow::ensure!(!master_password.is_empty(), "Vault master password cannot be blank");
    let final_path = vault_key_path()?;
    anyhow::ensure!(!final_path.exists(), "Credential vault already exists");
    let dir = credentials_dir()?;
    let token = Uuid::new_v4();
    let plain = dir.join(format!(".vault-key-{token}.tmp"));
    let encrypted = dir.join(format!(".vault-key-{token}.gpg"));
    let key = random_vault_key()?;
    secure_write(&plain, key.as_bytes())?;
    let result = gpg_encrypt_file(&plain, &encrypted, master_password, PASSWORD_WRAP_S2K_COUNT);
    let _ = fs::remove_file(&plain);
    result?;
    fs::rename(&encrypted, &final_path)?;
    fs::set_permissions(&final_path, fs::Permissions::from_mode(0o600))?;
    Ok(key)
}

fn unlock_vault(master_password: &str) -> Result<String> {
    anyhow::ensure!(!master_password.is_empty(), "Enter the vault master password");
    let encrypted = vault_key_path()?;
    anyhow::ensure!(encrypted.is_file(), "Credential vault has not been created yet");
    let plain = credentials_dir()?.join(format!(".unlock-{}.tmp", Uuid::new_v4()));
    gpg_decrypt_file(&encrypted, &plain, master_password)?;
    let result = fs::read_to_string(&plain).context("Unable to read decrypted vault key");
    let _ = fs::remove_file(&plain);
    let key = result?.trim().to_string();
    anyhow::ensure!(key.len() >= 100, "Decrypted vault key is invalid");
    Ok(key)
}

fn save_asset_secrets(asset_id: Uuid, secrets: &AssetSecrets, vault_key: &str) -> Result<()> {
    let dir = credentials_dir()?;
    let token = Uuid::new_v4();
    let plain = dir.join(format!(".asset-{asset_id}-{token}.json"));
    let encrypted = dir.join(format!(".asset-{asset_id}-{token}.gpg"));
    let json = serde_json::to_vec(secrets)?;
    secure_write(&plain, &json)?;
    let result = gpg_encrypt_file(&plain, &encrypted, vault_key, PACKAGE_S2K_COUNT);
    let _ = fs::remove_file(&plain);
    result?;
    let final_path = secret_path(asset_id)?;
    fs::rename(&encrypted, &final_path)?;
    fs::set_permissions(&final_path, fs::Permissions::from_mode(0o600))?;
    Ok(())
}

fn load_asset_secrets(asset_id: Uuid, vault_key: &str) -> Result<AssetSecrets> {
    let encrypted = secret_path(asset_id)?;
    if !encrypted.is_file() {
        return Ok(AssetSecrets::default());
    }
    let plain = credentials_dir()?.join(format!(".read-{asset_id}-{}.json", Uuid::new_v4()));
    gpg_decrypt_file(&encrypted, &plain, vault_key)?;
    let result = fs::read_to_string(&plain)
        .context("Unable to read decrypted credentials")
        .and_then(|json| serde_json::from_str::<AssetSecrets>(&json).context("Credential data is invalid"));
    let _ = fs::remove_file(&plain);
    result
}

fn delete_asset_secrets(asset_id: Uuid) {
    if let Ok(path) = secret_path(asset_id) {
        let _ = fs::remove_file(path);
    }
}

fn load_assets() -> Vec<Asset> {
    config_path()
        .ok()
        .and_then(|p| fs::read_to_string(p).ok())
        .and_then(|s| serde_json::from_str(&s).ok())
        .unwrap_or_default()
}

fn save_assets(assets: &[Asset]) {
    let Ok(path) = config_path() else { return; };
    let Ok(json) = serde_json::to_vec_pretty(assets) else { return; };
    let temp = path.with_extension(format!("json.{}.tmp", std::process::id()));

    if secure_write(&temp, &json).is_ok() {
        if fs::rename(&temp, &path).is_err() {
            let _ = fs::remove_file(&temp);
            log_event("ERROR", "Unable to atomically persist assets.json");
        }
    } else {
        let _ = fs::remove_file(&temp);
        log_event("ERROR", "Unable to write temporary assets.json");
    }
}

fn wake_on_lan(mac: &str) -> Result<()> {
    let bytes: Vec<u8> = mac
        .split(|c| c == ':' || c == '-')
        .map(|p| u8::from_str_radix(p, 16))
        .collect::<std::result::Result<Vec<_>, _>>()
        .context("Invalid MAC address")?;
    anyhow::ensure!(bytes.len() == 6, "MAC address must contain 6 bytes");

    let mut packet = vec![0xFF; 6];
    for _ in 0..16 {
        packet.extend_from_slice(&bytes);
    }
    let socket = UdpSocket::bind("0.0.0.0:0")?;
    socket.set_broadcast(true)?;
    socket.send_to(&packet, "255.255.255.255:9")?;
    Ok(())
}

fn styled_button(label: &str) -> Button {
    let button = Button::with_label(label);
    button.add_css_class("tool-button");
    button
}

fn styled_icon_button(label: &str, icon_name: &str) -> Button {
    let button = Button::new();
    button.add_css_class("tool-button");

    let content = GtkBox::new(Orientation::Horizontal, 7);
    let icon = Image::from_icon_name(icon_name);
    icon.set_pixel_size(16);
    let text = Label::new(Some(label));
    content.append(&icon);
    content.append(&text);
    button.set_child(Some(&content));
    button
}

fn confirmation_dialog(window: &ApplicationWindow, title: &str, body: &str) -> Dialog {
    let dialog = Dialog::builder()
        .transient_for(window)
        .modal(true)
        .title(title)
        .build();
    let label = Label::new(Some(body));
    label.set_wrap(true);
    label.set_xalign(0.0);
    label.set_margin_top(16);
    label.set_margin_bottom(16);
    label.set_margin_start(16);
    label.set_margin_end(16);
    dialog.content_area().append(&label);
    dialog.add_button("Cancel", ResponseType::Cancel);
    dialog.add_button("Confirm", ResponseType::Accept);
    dialog
}

fn set_status(label: &Label, text: &str, class_name: &str) {
    for class in ["status-neutral", "status-online", "status-offline", "status-error"] {
        label.remove_css_class(class);
    }
    label.add_css_class(class_name);
    label.set_text(text);
    let level = if class_name == "status-error" { "ERROR" } else { "INFO" };
    log_event(level, text.trim_start_matches('●').trim());
}

fn set_active_tool(active: &Button, all: &[&Button]) {
    for button in all {
        button.remove_css_class("active-tool");
    }
    active.add_css_class("active-tool");
}

fn rebuild_asset_list(list: &ListBox, assets: &[Asset], selected: Option<usize>) {
    while let Some(child) = list.first_child() {
        list.remove(&child);
    }
    for (i, asset) in assets.iter().enumerate() {
        let row = ListBoxRow::new();
        row.add_css_class("asset-row");

        let line = GtkBox::new(Orientation::Horizontal, 10);
        line.set_margin_top(9);
        line.set_margin_bottom(9);
        line.set_margin_start(10);
        line.set_margin_end(10);

        let icon = Image::from_icon_name("computer-symbolic");
        icon.set_pixel_size(20);
        icon.add_css_class("asset-icon");

        let labels = GtkBox::new(Orientation::Vertical, 2);
        labels.set_hexpand(true);
        let name = Label::new(Some(&asset.name));
        name.set_xalign(0.0);
        name.add_css_class("asset-name");
        let host_text = if asset.host.trim().is_empty() { "Not configured" } else { asset.host.trim() };
        let host = Label::new(Some(host_text));
        host.set_xalign(0.0);
        host.add_css_class("asset-host");
        labels.append(&name);
        labels.append(&host);

        line.append(&icon);
        line.append(&labels);
        row.set_child(Some(&line));
        list.append(&row);
        if selected == Some(i) {
            list.select_row(Some(&row));
        }
    }
}

fn selected_asset(assets: &Rc<RefCell<Vec<Asset>>>, selected: &Rc<RefCell<Option<usize>>>) -> Option<Asset> {
    let idx = *selected.borrow();
    idx.and_then(|i| assets.borrow().get(i).cloned())
}

// Operations should use what is currently visible in the Asset editor, even if
// the user has not pressed Save asset yet. The selected asset vector is the
// persisted snapshot; using it for live connection actions caused stale values
// (notably FTP username/host/ports) to be used immediately after editing.
fn current_asset_from_editor(
    assets: &Rc<RefCell<Vec<Asset>>>,
    selected: &Rc<RefCell<Option<usize>>>,
    editor: &AssetEditor,
) -> Option<Asset> {
    let idx = (*selected.borrow())?;
    let id = assets.borrow().get(idx)?.id;
    Some(asset_from_editor(editor, id))
}

fn fill_editor(editor: &AssetEditor, asset: &Asset) {
    editor.name.set_text(&asset.name);
    editor.host.set_text(&asset.host);
    editor.mac.set_text(&asset.mac);
    editor.username.set_text(&asset.username);
    editor.ssh_port.set_text(&asset.ssh_port.to_string());
    editor.transfer_port.set_text(&asset.transfer_port.to_string());
    editor.ftp_username.set_text(&asset.ftp_username);
    editor.ftp_port.set_text(&asset.ftp_port.to_string());
    editor.local_path.set_text(&asset.local_path);
    editor.remote_path.set_text(&asset.remote_path);
    editor.auto_connect.set_active(asset.auto_connect);
    editor.rdp_username.set_text(&asset.rdp_username);
    editor.rdp_domain.set_text(&asset.rdp_domain);
    editor.rdp_port.set_text(&asset.rdp_port.to_string());
    editor.rdp_dynamic_resolution.set_active(asset.rdp_dynamic_resolution);
    editor.rdp_clipboard.set_active(asset.rdp_clipboard);
    editor.rdp_tofu.set_active(asset.rdp_tofu);
}

fn fill_secret_editor(editor: &AssetEditor, secrets: &AssetSecrets) {
    editor.ssh_password.set_text(&secrets.ssh_password);
    editor.ftp_password.set_text(&secrets.ftp_password);
    editor.rdp_password.set_text(&secrets.rdp_password);
}

fn clear_secret_editor(editor: &AssetEditor) {
    editor.ssh_password.set_text("");
    editor.ftp_password.set_text("");
    editor.rdp_password.set_text("");
}

fn set_secret_editor_sensitive(editor: &AssetEditor, enabled: bool) {
    editor.ssh_password.set_sensitive(enabled);
    editor.ftp_password.set_sensitive(enabled);
    editor.rdp_password.set_sensitive(enabled);
}

fn secrets_from_editor(editor: &AssetEditor) -> AssetSecrets {
    AssetSecrets {
        ssh_password: editor.ssh_password.text().to_string(),
        ftp_password: editor.ftp_password.text().to_string(),
        rdp_password: editor.rdp_password.text().to_string(),
    }
}

fn clear_editor(editor: &AssetEditor) {
    fill_editor(editor, &Asset::default());
    clear_secret_editor(editor);
    editor.name.set_text("");
}

fn parse_port(entry: &Entry, fallback: u16) -> u16 {
    entry.text().trim().parse::<u16>().unwrap_or(fallback)
}

fn asset_from_editor(editor: &AssetEditor, existing_id: Uuid) -> Asset {
    Asset {
        id: existing_id,
        name: {
            let name = editor.name.text().trim().to_string();
            if name.is_empty() { "Unnamed asset".into() } else { name }
        },
        host: editor.host.text().trim().to_string(),
        username: editor.username.text().trim().to_string(),
        ssh_port: parse_port(&editor.ssh_port, 22),
        transfer_port: parse_port(&editor.transfer_port, 22),
        ftp_username: editor.ftp_username.text().trim().to_string(),
        ftp_port: parse_port(&editor.ftp_port, 21),
        mac: editor.mac.text().trim().to_string(),
        local_path: editor.local_path.text().trim().to_string(),
        remote_path: editor.remote_path.text().trim().to_string(),
        auto_connect: editor.auto_connect.is_active(),
        save_username: true,
        rdp_username: editor.rdp_username.text().trim().to_string(),
        rdp_domain: editor.rdp_domain.text().trim().to_string(),
        rdp_port: parse_port(&editor.rdp_port, 3389),
        rdp_dynamic_resolution: editor.rdp_dynamic_resolution.is_active(),
        rdp_clipboard: editor.rdp_clipboard.is_active(),
        rdp_tofu: editor.rdp_tofu.is_active(),
    }
}

fn ssh_target(asset: &Asset) -> String {
    if asset.username.trim().is_empty() {
        asset.host.clone()
    } else {
        format!("{}@{}", asset.username, asset.host)
    }
}

fn find_program(names: &[&str]) -> Option<PathBuf> {
    let path = std::env::var_os("PATH")?;
    for dir in std::env::split_paths(&path) {
        for name in names {
            let candidate = dir.join(name);
            if candidate.is_file() {
                return Some(candidate);
            }
        }
    }
    None
}

fn find_rdp_client() -> Option<PathBuf> {
    if std::env::var_os("WAYLAND_DISPLAY").is_some() {
        find_program(&["wlfreerdp3", "sdl-freerdp3", "xfreerdp3", "xfreerdp"])
    } else {
        find_program(&["xfreerdp3", "sdl-freerdp3", "wlfreerdp3", "xfreerdp"])
    }
}

fn check_tcp_port(host: &str, port: u16, service: &str) -> Result<()> {
    anyhow::ensure!(!host.trim().is_empty(), "Host/IP is not configured");
    let address = format!("{}:{port}", host.trim());
    let addrs: Vec<_> = address
        .to_socket_addrs()
        .with_context(|| format!("Unable to resolve {host}"))?
        .collect();
    anyhow::ensure!(!addrs.is_empty(), "No address returned for host");
    let mut last_error = String::new();
    for addr in addrs {
        match TcpStream::connect_timeout(&addr, Duration::from_millis(1500)) {
            Ok(_) => return Ok(()),
            Err(err) => last_error = err.to_string(),
        }
    }
    anyhow::bail!("{service} port {port} did not answer: {last_error}")
}

fn check_asset(asset: &Asset) -> Result<()> {
    check_tcp_port(&asset.host, asset.ssh_port, "SSH")
}

fn command_output_with_timeout(
    mut command: Command,
    timeout: Duration,
    label: &str,
) -> Result<std::process::Output> {
    let mut child = command
        .spawn()
        .with_context(|| format!("Unable to start {label}"))?;
    let started = std::time::Instant::now();

    loop {
        if let Some(status) = child.try_wait().with_context(|| format!("Unable to poll {label}"))? {
            let mut stdout = Vec::new();
            let mut stderr = Vec::new();
            if let Some(mut pipe) = child.stdout.take() {
                pipe.read_to_end(&mut stdout).context("Unable to read command stdout")?;
            }
            if let Some(mut pipe) = child.stderr.take() {
                pipe.read_to_end(&mut stderr).context("Unable to read command stderr")?;
            }
            return Ok(std::process::Output { status, stdout, stderr });
        }

        if started.elapsed() >= timeout {
            let _ = child.kill();
            let _ = child.wait();
            anyhow::bail!("{label} timed out after {} seconds", timeout.as_secs());
        }

        thread::sleep(Duration::from_millis(50));
    }
}

fn clean_ssh_stderr(stderr: &str) -> String {
    stderr
        .lines()
        .filter(|line| !line.contains("Permanently added") && !line.trim().is_empty())
        .collect::<Vec<_>>()
        .join("\n")
}

fn make_ssh_askpass_helper() -> Result<PathBuf> {
    let path = credentials_dir()?.join(format!(".ssh-askpass-{}.sh", Uuid::new_v4()));
    secure_write(
        &path,
        b"#!/bin/sh\nprintf '%s\\n' \"$BOXHOP_ASKPASS_PASSWORD\"\n",
    )?;
    fs::set_permissions(&path, fs::Permissions::from_mode(0o700))?;
    Ok(path)
}

fn test_ssh_connection(asset: &Asset, password: &str) -> Result<String> {
    check_tcp_port(&asset.host, asset.ssh_port, "SSH")?;
    let ssh = find_program(&["ssh"]).context(
        "OpenSSH client not found. Native Arch development: sudo pacman -S --needed openssh",
    )?;
    let helper = if password.is_empty() {
        None
    } else {
        Some(make_ssh_askpass_helper()?)
    };

    let result = (|| -> Result<std::process::Output> {
        let mut command = Command::new(ssh);
        command
            .arg("-p")
            .arg(asset.ssh_port.to_string())
            .arg("-o")
            .arg("ConnectTimeout=5")
            .arg("-o")
            .arg("StrictHostKeyChecking=accept-new")
            .arg("-o")
            .arg("NumberOfPasswordPrompts=1");
        if let Some(helper_path) = helper.as_ref() {
            command
                .arg("-o")
                .arg("BatchMode=no")
                .arg("-o")
                .arg("PreferredAuthentications=password,keyboard-interactive,publickey")
                .env("SSH_ASKPASS", helper_path)
                .env("SSH_ASKPASS_REQUIRE", "force")
                .env("BOXHOP_ASKPASS_PASSWORD", password)
                .env("DISPLAY", std::env::var("DISPLAY").unwrap_or_else(|_| ":0".into()));
        } else {
            command.arg("-o").arg("BatchMode=yes");
        }
        command
            .arg(ssh_target(asset))
            .arg("printf BOXHOP_SSH_OK")
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());
        command_output_with_timeout(command, Duration::from_secs(12), "SSH test")
    })();

    if let Some(helper_path) = helper {
        let _ = fs::remove_file(helper_path);
    }
    let output = result?;
    if !output.status.success() {
        let raw_stderr = String::from_utf8_lossy(&output.stderr);
        let stderr = clean_ssh_stderr(&raw_stderr);
        if stderr.is_empty() {
            anyhow::bail!("SSH authentication failed");
        }
        anyhow::bail!("{stderr}");
    }
    anyhow::ensure!(
        String::from_utf8_lossy(&output.stdout).contains("BOXHOP_SSH_OK"),
        "SSH connected but the test command did not complete"
    );
    Ok(format!("SSH port {} open; authentication OK", asset.ssh_port))
}

fn read_ftp_reply(reader: &mut BufReader<TcpStream>) -> Result<(u16, String)> {
    let mut line = String::new();
    reader.read_line(&mut line).context("FTP server closed the connection")?;
    let code_text = line.get(0..3).context("Invalid FTP reply")?;
    let code: u16 = code_text.parse().context("Invalid FTP reply code")?;
    let mut full = line.trim_end().to_string();
    if line.as_bytes().get(3) == Some(&b'-') {
        let terminator = format!("{code} ");
        loop {
            line.clear();
            reader.read_line(&mut line).context("FTP server closed a multiline reply")?;
            anyhow::ensure!(!line.is_empty(), "FTP server closed a multiline reply");
            full.push('\n');
            full.push_str(line.trim_end());
            if line.starts_with(&terminator) {
                break;
            }
        }
    }
    Ok((code, full))
}

fn ftp_send(stream: &mut TcpStream, command: &str) -> Result<()> {
    stream.write_all(command.as_bytes())?;
    stream.write_all(b"\r\n")?;
    stream.flush()?;
    Ok(())
}

fn ensure_single_line(value: &str, label: &str) -> Result<()> {
    anyhow::ensure!(
        !value.contains('\n') && !value.contains('\r'),
        "{label} cannot contain a line break"
    );
    Ok(())
}

fn test_ftp_connection(asset: &Asset, password: &str) -> Result<String> {
    check_tcp_port(&asset.host, asset.ftp_port, "FTP")?;
    ensure_single_line(&asset.ftp_username, "FTP username")?;
    ensure_single_line(password, "FTP password")?;
    if asset.ftp_username.trim().is_empty() {
        return Ok(format!(
            "FTP port {} open; set an FTP username to test login",
            asset.ftp_port
        ));
    }

    let address = format!("{}:{}", asset.host.trim(), asset.ftp_port);
    let mut addrs = address.to_socket_addrs().context("Unable to resolve FTP host")?;
    let addr = addrs.next().context("No address returned for FTP host")?;
    let mut stream = TcpStream::connect_timeout(&addr, Duration::from_secs(3))?;
    stream.set_read_timeout(Some(Duration::from_secs(5)))?;
    stream.set_write_timeout(Some(Duration::from_secs(5)))?;
    let mut reader = BufReader::new(stream.try_clone()?);

    let (banner, banner_text) = read_ftp_reply(&mut reader)?;
    anyhow::ensure!(banner == 220, "FTP server rejected connection: {banner_text}");
    ftp_send(&mut stream, &format!("USER {}", asset.ftp_username))?;
    let (user_code, user_text) = read_ftp_reply(&mut reader)?;
    match user_code {
        230 => {}
        331 => {
            ftp_send(&mut stream, &format!("PASS {password}"))?;
            let (pass_code, pass_text) = read_ftp_reply(&mut reader)?;
            anyhow::ensure!(pass_code == 230, "FTP authentication failed: {pass_text}");
        }
        _ => anyhow::bail!("FTP username rejected: {user_text}"),
    }
    let _ = ftp_send(&mut stream, "QUIT");
    Ok(format!("FTP port {} open; login OK", asset.ftp_port))
}


struct FtpSession {
    stream: TcpStream,
    reader: BufReader<TcpStream>,
}

impl FtpSession {
    fn connect(asset: &Asset, password: &str) -> Result<Self> {
        anyhow::ensure!(!asset.host.trim().is_empty(), "Host/IP is not configured");
        ensure_single_line(&asset.ftp_username, "FTP username")?;
        ensure_single_line(password, "FTP password")?;
        anyhow::ensure!(!asset.ftp_username.trim().is_empty(), "FTP username is not configured");

        let address = format!("{}:{}", asset.host.trim(), asset.ftp_port);
        let mut addrs = address.to_socket_addrs().context("Unable to resolve FTP host")?;
        let addr = addrs.next().context("No address returned for FTP host")?;
        let stream = TcpStream::connect_timeout(&addr, Duration::from_secs(5))?;
        stream.set_read_timeout(Some(Duration::from_secs(10)))?;
        stream.set_write_timeout(Some(Duration::from_secs(10)))?;
        let reader = BufReader::new(stream.try_clone()?);
        let mut session = Self { stream, reader };

        let (banner, banner_text) = read_ftp_reply(&mut session.reader)?;
        anyhow::ensure!(banner == 220, "FTP server rejected connection: {banner_text}");
        ftp_send(&mut session.stream, &format!("USER {}", asset.ftp_username))?;
        let (user_code, user_text) = read_ftp_reply(&mut session.reader)?;
        match user_code {
            230 => {}
            331 => {
                ftp_send(&mut session.stream, &format!("PASS {password}"))?;
                let (pass_code, pass_text) = read_ftp_reply(&mut session.reader)?;
                anyhow::ensure!(pass_code == 230, "FTP authentication failed: {pass_text}");
            }
            _ => anyhow::bail!("FTP username rejected: {user_text}"),
        }
        session.command_expect("TYPE I", &[200])?;
        Ok(session)
    }

    fn command(&mut self, command: &str) -> Result<(u16, String)> {
        ensure_single_line(command, "FTP command")?;
        ftp_send(&mut self.stream, command)?;
        read_ftp_reply(&mut self.reader)
    }

    fn command_expect(&mut self, command: &str, accepted: &[u16]) -> Result<String> {
        let (code, text) = self.command(command)?;
        anyhow::ensure!(accepted.contains(&code), "FTP command failed ({code}): {text}");
        Ok(text)
    }

    fn cwd(&mut self, path: &str) -> Result<()> {
        ensure_single_line(path, "Remote path")?;
        self.command_expect(&format!("CWD {path}"), &[250])?;
        Ok(())
    }

    fn pwd(&mut self) -> Result<String> {
        let (code, text) = self.command("PWD")?;
        anyhow::ensure!(code == 257, "FTP PWD failed ({code}): {text}");
        if let Some(start) = text.find('"') {
            if let Some(end_rel) = text[start + 1..].find('"') {
                return Ok(text[start + 1..start + 1 + end_rel].replace("\"\"", "\""));
            }
        }
        Ok(text.get(4..).unwrap_or(".").trim().to_string())
    }

    fn passive_data_stream(&mut self) -> Result<TcpStream> {
        let (epsv_code, epsv_text) = self.command("EPSV")?;
        if epsv_code == 229 {
            if let Some(open) = epsv_text.rfind('(') {
                if let Some(close_rel) = epsv_text[open + 1..].find(')') {
                    let body = &epsv_text[open + 1..open + 1 + close_rel];
                    let delimiter = body.chars().next().context("Invalid EPSV reply")?;
                    let parts: Vec<&str> = body.split(delimiter).collect();
                    if parts.len() >= 4 {
                        if let Ok(port) = parts[3].parse::<u16>() {
                            let peer = self.stream.peer_addr()?;
                            let addr = std::net::SocketAddr::new(peer.ip(), port);
                            let data = TcpStream::connect_timeout(&addr, Duration::from_secs(5))?;
                            data.set_read_timeout(Some(Duration::from_secs(30)))?;
                            data.set_write_timeout(Some(Duration::from_secs(30)))?;
                            return Ok(data);
                        }
                    }
                }
            }
        }

        let (pasv_code, pasv_text) = self.command("PASV")?;
        anyhow::ensure!(pasv_code == 227, "FTP passive mode failed: {pasv_text}");
        let open = pasv_text.rfind('(').context("Invalid PASV reply")?;
        let close = pasv_text[open + 1..].find(')').map(|v| v + open + 1).context("Invalid PASV reply")?;
        let values: Vec<u16> = pasv_text[open + 1..close]
            .split(',')
            .map(|part| part.trim().parse::<u16>())
            .collect::<std::result::Result<Vec<_>, _>>()
            .context("Invalid PASV address")?;
        anyhow::ensure!(values.len() == 6 && values.iter().all(|v| *v <= 255), "Invalid PASV address");
        let port = ((values[4] as u32) * 256 + values[5] as u32) as u16;
        // Use the control connection peer IP with the PASV port. This avoids
        // broken/NAT-private PASV addresses and prevents FTP bounce to a third host.
        let peer = self.stream.peer_addr()?;
        let socket = std::net::SocketAddr::new(peer.ip(), port);
        let data = TcpStream::connect_timeout(&socket, Duration::from_secs(5))?;
        data.set_read_timeout(Some(Duration::from_secs(30)))?;
        data.set_write_timeout(Some(Duration::from_secs(30)))?;
        Ok(data)
    }

    fn read_data_command(&mut self, command: &str) -> Result<Vec<u8>> {
        let mut data = self.passive_data_stream()?;
        let (code, text) = self.command(command)?;
        anyhow::ensure!(code == 125 || code == 150, "FTP data command failed ({code}): {text}");
        let mut out = Vec::new();
        data.read_to_end(&mut out)?;
        drop(data);
        let (done_code, done_text) = read_ftp_reply(&mut self.reader)?;
        anyhow::ensure!(done_code == 226 || done_code == 250, "FTP transfer did not complete ({done_code}): {done_text}");
        Ok(out)
    }

    fn read_data_to_writer<W: Write>(&mut self, command: &str, target: &mut W) -> Result<u64> {
        let mut data = self.passive_data_stream()?;
        let (code, text) = self.command(command)?;
        anyhow::ensure!(code == 125 || code == 150, "FTP data command failed ({code}): {text}");
        let copied = std::io::copy(&mut data, target)?;
        target.flush()?;
        drop(data);
        let (done_code, done_text) = read_ftp_reply(&mut self.reader)?;
        anyhow::ensure!(done_code == 226 || done_code == 250, "FTP transfer did not complete ({done_code}): {done_text}");
        Ok(copied)
    }

    fn write_data_command(&mut self, command: &str, source: &mut File) -> Result<()> {
        let mut data = self.passive_data_stream()?;
        let (code, text) = self.command(command)?;
        anyhow::ensure!(code == 125 || code == 150, "FTP data command failed ({code}): {text}");
        std::io::copy(source, &mut data)?;
        data.flush()?;
        let _ = data.shutdown(std::net::Shutdown::Write);
        drop(data);
        let (done_code, done_text) = read_ftp_reply(&mut self.reader)?;
        anyhow::ensure!(done_code == 226 || done_code == 250, "FTP upload did not complete ({done_code}): {done_text}");
        Ok(())
    }
}

fn parse_ftp_mlsd(text: &str) -> Vec<FileItem> {
    let mut items = Vec::new();
    for raw in text.lines() {
        let line = raw.trim_end_matches(&['\r', '\n'][..]);
        let Some(split_at) = line.find(char::is_whitespace) else { continue; };
        let facts = &line[..split_at];
        let name = line[split_at..].trim_start();
        if name.is_empty() { continue; }
        let mut kind = None::<String>;
        for fact in facts.split(';') {
            let lower = fact.to_ascii_lowercase();
            if let Some(value) = lower.strip_prefix("type=") {
                kind = Some(value.to_string());
                break;
            }
        }
        match kind.as_deref().unwrap_or("") {
            "cdir" | "pdir" => continue,
            "dir" => items.push(FileItem { name: name.to_string(), is_dir: true }),
            _ => items.push(FileItem { name: name.to_string(), is_dir: false }),
        }
    }
    items
}

fn parse_ftp_list(text: &str) -> Vec<FileItem> {
    let mut items = Vec::new();
    for raw in text.lines() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with("total ") { continue; }
        let fields: Vec<&str> = line.split_whitespace().collect();
        if fields.len() >= 9 && fields[0].len() >= 1 {
            let first = fields[0].as_bytes()[0] as char;
            if matches!(first, 'd' | '-' | 'l') {
                let mut name = fields[8..].join(" ");
                if first == 'l' {
                    if let Some((left, _)) = name.split_once(" -> ") { name = left.to_string(); }
                }
                if name != "." && name != ".." {
                    items.push(FileItem { name, is_dir: first == 'd' });
                }
                continue;
            }
        }
        if fields.len() >= 4 && (fields[2].eq_ignore_ascii_case("<DIR>") || fields[2].parse::<u64>().is_ok()) {
            let name = fields[3..].join(" ");
            if name != "." && name != ".." {
                items.push(FileItem { name, is_dir: fields[2].eq_ignore_ascii_case("<DIR>") });
            }
        }
    }
    items
}

fn sort_file_items(mut items: Vec<FileItem>) -> Vec<FileItem> {
    items.sort_by(|a, b| b.is_dir.cmp(&a.is_dir).then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase())));
    items
}

fn list_remote_ftp(asset: &Asset, password: &str, path: &str) -> Result<RemoteListing> {
    // A blank path or "." means the FTP account's login directory. Do not force "/";
    // many vsftpd accounts are chrooted and their login directory is the useful root.
    let requested = if path.trim().is_empty() { "." } else { path.trim() };
    let mut session = FtpSession::connect(asset, password)?;
    if requested != "." {
        session.cwd(requested)?;
    }
    let actual_path = session.pwd().unwrap_or_else(|_| requested.to_string());

    // Prefer MLSD. Fall back to LIST only when MLSD fails or returns a
    // non-empty response that we cannot recognise. A valid empty MLSD listing
    // must stay empty instead of causing a second slow network round trip.
    let (mut items, need_list_fallback) = match session.read_data_command("MLSD") {
        Ok(bytes) => {
            let text = String::from_utf8_lossy(&bytes);
            let parsed = parse_ftp_mlsd(&text);
            let nonempty_lines: Vec<&str> = text.lines().filter(|line| !line.trim().is_empty()).collect();
            let recognised = nonempty_lines.is_empty()
                || nonempty_lines.iter().all(|line| line.to_ascii_lowercase().contains("type="));
            (parsed, !recognised)
        }
        Err(_) => (Vec::new(), true),
    };

    if need_list_fallback {
        let mut fallback = FtpSession::connect(asset, password)?;
        if requested != "." {
            fallback.cwd(requested)?;
        }
        let bytes = fallback.read_data_command("LIST")?;
        items = parse_ftp_list(&String::from_utf8_lossy(&bytes));
    }

    Ok(RemoteListing {
        path: actual_path,
        items: sort_file_items(items),
    })
}

fn ftp_store_file(asset: &Asset, password: &str, local: &Path, remote: &str) -> Result<()> {
    ensure_single_line(remote, "Remote path")?;
    let mut session = FtpSession::connect(asset, password)?;
    let mut source = File::open(local).with_context(|| format!("Unable to open local file {}", local.display()))?;
    session.write_data_command(&format!("STOR {remote}"), &mut source)
}

fn ftp_make_dir(asset: &Asset, password: &str, remote: &str) -> Result<()> {
    ensure_single_line(remote, "Remote path")?;
    let mut session = FtpSession::connect(asset, password)?;
    let (code, text) = session.command(&format!("MKD {remote}"))?;
    if code == 257 || code == 250 || code == 550 {
        return Ok(());
    }
    anyhow::bail!("FTP could not create directory ({code}): {text}")
}

fn ftp_upload_path(asset: &Asset, password: &str, local: &Path, remote: &str) -> Result<()> {
    if local.is_dir() {
        ftp_make_dir(asset, password, remote)?;
        for entry in fs::read_dir(local)? {
            let entry = entry?;
            let name = entry.file_name().to_string_lossy().into_owned();
            ensure_single_line(&name, "File name")?;
            let child_remote = join_remote(remote, &name);
            ftp_upload_path(asset, password, &entry.path(), &child_remote)?;
        }
        Ok(())
    } else {
        ftp_store_file(asset, password, local, remote)
    }
}

fn ftp_retrieve_file(asset: &Asset, password: &str, remote: &str, local: &Path) -> Result<()> {
    ensure_single_line(remote, "Remote path")?;
    if let Some(parent) = local.parent() { fs::create_dir_all(parent)?; }

    let partial = local.with_extension(format!("{}.boxhop-part", local.extension().and_then(|v| v.to_str()).unwrap_or("download")));
    let mut file = File::create(&partial)
        .with_context(|| format!("Unable to create temporary local file {}", partial.display()))?;
    let mut session = FtpSession::connect(asset, password)?;
    let transfer = session.read_data_to_writer(&format!("RETR {remote}"), &mut file);
    if let Err(err) = transfer {
        let _ = fs::remove_file(&partial);
        return Err(err);
    }
    file.sync_all()?;
    drop(file);
    fs::rename(&partial, local)
        .with_context(|| format!("Unable to commit downloaded file {}", local.display()))?;
    Ok(())
}

fn ftp_download_path(asset: &Asset, password: &str, remote: &str, local: &Path, is_dir: bool) -> Result<()> {
    if is_dir {
        fs::create_dir_all(local)?;
        let children = list_remote_ftp(asset, password, remote)?;
        for child in children.items {
            let child_remote = join_remote(remote, &child.name);
            let child_local = local.join(&child.name);
            ftp_download_path(asset, password, &child_remote, &child_local, child.is_dir)?;
        }
        Ok(())
    } else {
        ftp_retrieve_file(asset, password, remote, local)
    }
}

fn ftp_upload(asset: &Asset, password: &str, local_path: &str, remote_path: &str, item: &FileItem) -> Result<()> {
    let local = PathBuf::from(local_path).join(&item.name);
    let remote = join_remote(remote_path, &item.name);
    ftp_upload_path(asset, password, &local, &remote)
}

fn ftp_download(asset: &Asset, password: &str, local_path: &str, remote_path: &str, item: &FileItem) -> Result<()> {
    let local = PathBuf::from(local_path).join(&item.name);
    let remote = join_remote(remote_path, &item.name);
    ftp_download_path(asset, password, &remote, &local, item.is_dir)
}

fn list_remote_by_protocol(protocol: RemoteProtocol, asset: &Asset, password: &str, path: &str) -> Result<RemoteListing> {
    match protocol {
        RemoteProtocol::Sftp => list_remote_sftp(asset, path),
        RemoteProtocol::Ftp => list_remote_ftp(asset, password, path),
    }
}

fn upload_by_protocol(protocol: RemoteProtocol, asset: &Asset, password: &str, local_path: &str, remote_path: &str, item: &FileItem) -> Result<()> {
    match protocol {
        RemoteProtocol::Sftp => sftp_upload(asset, local_path, remote_path, item),
        RemoteProtocol::Ftp => ftp_upload(asset, password, local_path, remote_path, item),
    }
}

fn download_by_protocol(protocol: RemoteProtocol, asset: &Asset, password: &str, local_path: &str, remote_path: &str, item: &FileItem) -> Result<()> {
    match protocol {
        RemoteProtocol::Sftp => sftp_download(asset, local_path, remote_path, item),
        RemoteProtocol::Ftp => ftp_download(asset, password, local_path, remote_path, item),
    }
}

fn rdp_args(asset: &Asset, password: &str, auth_only: bool) -> Result<Vec<String>> {
    ensure_single_line(&asset.host, "RDP host")?;
    ensure_single_line(&asset.rdp_username, "RDP username")?;
    ensure_single_line(&asset.rdp_domain, "RDP domain")?;
    ensure_single_line(password, "RDP password")?;
    let mut args = vec![format!("/v:{}:{}", asset.host, asset.rdp_port)];
    if !asset.rdp_username.trim().is_empty() {
        args.push(format!("/u:{}", asset.rdp_username));
    }
    if !password.is_empty() {
        args.push(format!("/p:{password}"));
    }
    if !asset.rdp_domain.trim().is_empty() {
        args.push(format!("/d:{}", asset.rdp_domain));
    }
    if asset.rdp_dynamic_resolution && !auth_only {
        args.push("+dynamic-resolution".into());
    }
    if asset.rdp_clipboard && !auth_only {
        args.push("+clipboard".into());
    }
    if asset.rdp_tofu {
        args.push("/cert:tofu".into());
    }
    if auth_only {
        args.push("/auth-only".into());
    } else {
        args.push("+auto-reconnect".into());
    }
    Ok(args)
}

fn write_freerdp_args(mut stdin: impl Write, args: &[String]) -> Result<()> {
    for arg in args {
        stdin.write_all(arg.as_bytes())?;
        stdin.write_all(b"\n")?;
    }
    stdin.flush()?;
    Ok(())
}

fn test_rdp_connection(asset: &Asset, password: &str) -> Result<String> {
    check_tcp_port(&asset.host, asset.rdp_port, "RDP")?;
    if asset.rdp_username.trim().is_empty() || password.is_empty() {
        return Ok(format!(
            "RDP port {} open; unlock/save username + password to test authentication",
            asset.rdp_port
        ));
    }
    let client = find_rdp_client().context(
        "RDP port is open, but FreeRDP 3 is not installed. Native Arch development: sudo pacman -S --needed freerdp",
    )?;
    let args = rdp_args(asset, password, true)?;
    let mut child = Command::new(client)
        .arg("/args-from:stdin")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .context("Unable to start FreeRDP authentication test")?;
    if let Some(stdin) = child.stdin.take() {
        write_freerdp_args(stdin, &args)?;
    }
    let output = child.wait_with_output()?;
    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr).trim().to_string();
        let stdout = String::from_utf8_lossy(&output.stdout).trim().to_string();
        let detail = if !stderr.is_empty() { stderr } else { stdout };
        if detail.is_empty() {
            anyhow::bail!("RDP authentication failed");
        }
        anyhow::bail!("{detail}");
    }
    Ok(format!("RDP port {} open; authentication OK", asset.rdp_port))
}

fn spawn_terminal_command(
    terminal: &Terminal,
    argv: Vec<String>,
    terminal_busy: &Rc<RefCell<bool>>,
    header: &Label,
    status: &Label,
    title: &str,
) {
    if *terminal_busy.borrow() {
        set_status(status, "Terminal already active — type exit first", "status-error");
        return;
    }
    if argv.is_empty() {
        return;
    }
    terminal.reset(true, true);
    header.set_text(title);
    *terminal_busy.borrow_mut() = true;
    let refs: Vec<&str> = argv.iter().map(String::as_str).collect();
    let busy = terminal_busy.clone();
    let status_clone = status.clone();
    terminal.spawn_async(
        vte4::PtyFlags::DEFAULT,
        None,
        &refs,
        &[],
        glib::SpawnFlags::DEFAULT,
        || {},
        -1,
        None::<&gio::Cancellable>,
        move |result| {
            if let Err(err) = result {
                *busy.borrow_mut() = false;
                set_status(&status_clone, &format!("Terminal start failed: {err}"), "status-error");
            }
        },
    );
}

fn launch_rdp(asset: &Asset, password: &str) -> Result<()> {
    anyhow::ensure!(!asset.host.trim().is_empty(), "Host/IP is not configured");
    let client = find_rdp_client().context(
        "FreeRDP 3 client not found. Native Arch development: sudo pacman -S --needed freerdp. The final Flatpak will bundle its RDP client.",
    )?;
    let args = rdp_args(asset, password, false)?;
    let mut child = Command::new(client)
        .arg("/args-from:stdin")
        .stdin(Stdio::piped())
        .spawn()
        .context("Unable to launch FreeRDP")?;
    if let Some(stdin) = child.stdin.take() {
        write_freerdp_args(stdin, &args)?;
    }
    Ok(())
}

fn main() -> glib::ExitCode {
    initialise_logging();
    let app = Application::builder().application_id(APP_ID).build();
    app.connect_activate(build_ui);
    let code = app.run();
    finish_logging();
    code
}

fn build_ui(app: &Application) {
    let css = gtk::CssProvider::new();
    css.load_from_string(include_str!("../data/style.css"));
    gtk::style_context_add_provider_for_display(
        &gdk::Display::default().expect("display"),
        &css,
        gtk::STYLE_PROVIDER_PRIORITY_APPLICATION,
    );

    let assets = Rc::new(RefCell::new(load_assets()));
    let selected = Rc::new(RefCell::new(None::<usize>));
    let terminal_busy = Rc::new(RefCell::new(false));
    let vault_key = Rc::new(RefCell::new(None::<String>));

    let window = ApplicationWindow::builder()
        .application(app)
        .title("BoxHop")
        .default_width(1320)
        .default_height(820)
        .build();
    window.set_icon_name(Some(APP_ID));

    let root = GtkBox::new(Orientation::Horizontal, 0);
    let sidebar = GtkBox::new(Orientation::Vertical, 10);
    sidebar.add_css_class("sidebar");
    sidebar.set_width_request(200);
    sidebar.set_margin_top(14);
    sidebar.set_margin_bottom(14);
    sidebar.set_margin_start(14);
    sidebar.set_margin_end(14);

    let brand_row = GtkBox::new(Orientation::Horizontal, 9);
    brand_row.add_css_class("brand-row");
    let brand_icon = Image::from_icon_name(APP_ID);
    brand_icon.set_pixel_size(36);
    let brand = Label::new(Some("BOXHOP"));
    brand.add_css_class("brand");
    brand.set_xalign(0.0);
    brand_row.append(&brand_icon);
    brand_row.append(&brand);
    sidebar.append(&brand_row);

    let brand_subtitle = Label::new(Some("Remote systems, one place"));
    brand_subtitle.add_css_class("brand-subtitle");
    brand_subtitle.set_xalign(0.0);
    sidebar.append(&brand_subtitle);

    let add_asset = styled_icon_button("Add asset", "list-add-symbolic");
    add_asset.add_css_class("primary");
    add_asset.add_css_class("add-asset");
    sidebar.append(&add_asset);

    let asset_list = ListBox::new();
    asset_list.add_css_class("asset-list");
    asset_list.set_selection_mode(gtk::SelectionMode::Single);
    let asset_scroll = ScrolledWindow::builder().vexpand(true).child(&asset_list).build();
    sidebar.append(&asset_scroll);

    let sidebar_footer = Label::new(Some(&format!("v{APP_VERSION}  •  MIT")));
    sidebar_footer.set_xalign(0.0);
    sidebar_footer.add_css_class("sidebar-footer");
    sidebar.append(&sidebar_footer);

    let content = GtkBox::new(Orientation::Vertical, 12);
    content.add_css_class("content");
    content.set_margin_top(14);
    content.set_margin_bottom(14);
    content.set_margin_start(6);
    content.set_margin_end(14);

    let toolbar = GtkBox::new(Orientation::Horizontal, 8);
    toolbar.add_css_class("toolbar");
    let terminal_btn = styled_icon_button("Terminal", "utilities-terminal-symbolic");
    let files_btn = styled_icon_button("Files", "folder-symbolic");
    let rdp_btn = styled_icon_button("RDP", "video-display-symbolic");
    let logs_btn = styled_icon_button("Logs", "text-x-generic-symbolic");
    let asset_btn = styled_icon_button("Asset", "preferences-system-symbolic");
    let spacer = GtkBox::new(Orientation::Horizontal, 0);
    spacer.set_hexpand(true);
    let status = Label::new(Some("● No asset selected"));
    status.add_css_class("status-pill");
    status.add_css_class("status-neutral");
    status.set_xalign(1.0);
    let check_btn = styled_icon_button("Check", "view-refresh-symbolic");
    let wol_btn = styled_icon_button("Wake", "network-wired-symbolic");
    let shutdown_btn = styled_icon_button("Shutdown", "system-shutdown-symbolic");
    shutdown_btn.add_css_class("shutdown-button");
    terminal_btn.add_css_class("active-tool");
    toolbar.append(&terminal_btn);
    toolbar.append(&files_btn);
    toolbar.append(&rdp_btn);
    toolbar.append(&logs_btn);
    toolbar.append(&asset_btn);
    toolbar.append(&spacer);
    toolbar.append(&status);
    toolbar.append(&check_btn);
    toolbar.append(&wol_btn);
    toolbar.append(&shutdown_btn);
    content.append(&toolbar);

    let stack = Stack::new();
    stack.set_hexpand(true);
    stack.set_vexpand(true);

    // Terminal page
    let terminal_page = GtkBox::new(Orientation::Vertical, 8);
    terminal_page.add_css_class("panel");
    let terminal_top = GtkBox::new(Orientation::Horizontal, 8);
    let terminal_header = Label::new(Some("Terminal — select an asset"));
    terminal_header.set_xalign(0.0);
    terminal_header.set_hexpand(true);
    terminal_header.add_css_class("page-title");
    let ssh_connect = styled_icon_button("Connect SSH", "network-wired-symbolic");
    let local_shell = styled_icon_button("Local shell", "utilities-terminal-symbolic");
    terminal_top.append(&terminal_header);
    terminal_top.append(&ssh_connect);
    terminal_top.append(&local_shell);
    terminal_page.append(&terminal_top);
    let terminal = Terminal::new();
    terminal.set_hexpand(true);
    terminal.set_vexpand(true);
    terminal_page.append(&terminal);
    stack.add_named(&terminal_page, Some("terminal"));

    // Files page
    let files_page = GtkBox::new(Orientation::Vertical, 10);
    files_page.add_css_class("panel");
    let files_title = Label::new(Some("Files — SFTP / FTP dual-pane browser"));
    files_title.set_xalign(0.0);
    files_title.add_css_class("page-title");
    files_page.append(&files_title);

    let file_actions = GtkBox::new(Orientation::Horizontal, 8);
    file_actions.add_css_class("file-actions");
    let sftp_mode_btn = styled_icon_button("SFTP", "network-server-symbolic");
    let ftp_mode_btn = styled_icon_button("FTP", "network-server-symbolic");
    sftp_mode_btn.add_css_class("active-tool");
    let local_up_btn = styled_icon_button("Local up", "go-up-symbolic");
    let remote_up_btn = styled_icon_button("Remote up", "go-up-symbolic");
    let files_refresh_btn = styled_icon_button("Refresh", "view-refresh-symbolic");
    let upload_btn = styled_icon_button("Upload", "go-next-symbolic");
    let download_btn = styled_icon_button("Download", "go-previous-symbolic");
    file_actions.append(&sftp_mode_btn);
    file_actions.append(&ftp_mode_btn);
    file_actions.append(&local_up_btn);
    file_actions.append(&remote_up_btn);
    file_actions.append(&files_refresh_btn);
    file_actions.append(&upload_btn);
    file_actions.append(&download_btn);
    files_page.append(&file_actions);

    let paths = GtkBox::new(Orientation::Horizontal, 8);
    let local_path_view = Entry::builder().placeholder_text("Local directory").hexpand(true).build();
    let remote_path_view = Entry::builder().placeholder_text("Remote directory").hexpand(true).build();
    local_path_view.add_css_class("path-entry");
    remote_path_view.add_css_class("path-entry");
    paths.append(&local_path_view);
    paths.append(&remote_path_view);
    files_page.append(&paths);

    let local_items = Rc::new(RefCell::new(Vec::<FileItem>::new()));
    let remote_items = Rc::new(RefCell::new(Vec::<FileItem>::new()));
    let current_local_path = Rc::new(RefCell::new(local_home()));
    let current_remote_path = Rc::new(RefCell::new(".".to_string()));
    let remote_protocol = Rc::new(RefCell::new(RemoteProtocol::Sftp));

    let panes = Paned::new(Orientation::Horizontal);
    let local_list = ListBox::new();
    local_list.add_css_class("file-list");
    local_list.set_selection_mode(gtk::SelectionMode::Single);
    let remote_list = ListBox::new();
    remote_list.add_css_class("file-list");
    remote_list.set_selection_mode(gtk::SelectionMode::Single);
    let local_scroll = ScrolledWindow::builder().hexpand(true).vexpand(true).child(&local_list).build();
    let remote_scroll = ScrolledWindow::builder().hexpand(true).vexpand(true).child(&remote_list).build();
    local_scroll.add_css_class("file-pane");
    remote_scroll.add_css_class("file-pane");
    panes.set_start_child(Some(&local_scroll));
    panes.set_end_child(Some(&remote_scroll));
    panes.set_resize_start_child(true);
    panes.set_resize_end_child(true);
    panes.set_vexpand(true);
    files_page.append(&panes);

    let files_note = Label::new(Some("Choose SFTP or FTP above. Connection actions use the values currently shown in Asset settings, even before Save asset is pressed. Save asset persists them. SFTP uses OpenSSH key/agent authentication. FTP uses the encrypted FTP password from the selected asset. Plain FTP is implemented in-process; FTPS is not enabled yet."));
    files_note.set_xalign(0.0);
    files_note.set_wrap(true);
    files_note.add_css_class("muted");
    files_page.append(&files_note);
    stack.add_named(&files_page, Some("files"));

    // RDP page
    let rdp_page = GtkBox::new(Orientation::Vertical, 12);
    rdp_page.add_css_class("panel");
    let rdp_title = Label::new(Some("Remote Desktop (RDP)"));
    rdp_title.set_xalign(0.0);
    rdp_title.add_css_class("page-title");
    rdp_page.append(&rdp_title);

    let rdp_summary = Label::new(Some("Select an asset. RDP passwords can be stored in the encrypted credential vault and are passed to FreeRDP through stdin rather than the process command line."));
    rdp_summary.set_xalign(0.0);
    rdp_summary.set_wrap(true);
    rdp_summary.add_css_class("muted");
    rdp_page.append(&rdp_summary);

    let rdp_info = Label::new(None);
    rdp_info.set_xalign(0.0);
    rdp_info.add_css_class("rdp-info");
    rdp_page.append(&rdp_info);

    let rdp_connect = styled_icon_button("Connect RDP", "video-display-symbolic");
    rdp_connect.add_css_class("primary");
    rdp_connect.set_halign(gtk::Align::Start);
    rdp_page.append(&rdp_connect);

    let rdp_note = Label::new(Some(
        "Current development build launches FreeRDP in its own native window. The final Flatpak will bundle the RDP client so this is not a hidden host dependency.",
    ));
    rdp_note.set_xalign(0.0);
    rdp_note.set_wrap(true);
    rdp_note.add_css_class("muted");
    rdp_page.append(&rdp_note);
    stack.add_named(&rdp_page, Some("rdp"));

    // Logs page
    let logs_page = GtkBox::new(Orientation::Vertical, 10);
    logs_page.add_css_class("panel");
    let logs_top = GtkBox::new(Orientation::Horizontal, 8);
    let logs_title = Label::new(Some("BoxHop logs"));
    logs_title.set_xalign(0.0);
    logs_title.set_hexpand(true);
    logs_title.add_css_class("page-title");
    let logs_refresh_btn = styled_button("Refresh logs");
    logs_top.append(&logs_title);
    logs_top.append(&logs_refresh_btn);
    logs_page.append(&logs_top);

    let logs_path_text = log_dir()
        .map(|p| format!("Persistent logs: {}", p.display()))
        .unwrap_or_else(|_| "Persistent log directory unavailable".into());
    let logs_path_label = Label::new(Some(&logs_path_text));
    logs_path_label.set_xalign(0.0);
    logs_path_label.set_wrap(true);
    logs_path_label.add_css_class("muted");
    logs_page.append(&logs_path_label);

    let log_panes = Paned::new(Orientation::Vertical);
    log_panes.set_hexpand(true);
    log_panes.set_vexpand(true);

    let runtime_box = GtkBox::new(Orientation::Vertical, 6);
    let runtime_title = Label::new(Some("Running log — boxhop.log"));
    runtime_title.set_xalign(0.0);
    runtime_title.add_css_class("panel-title");
    let runtime_log_view = TextView::new();
    runtime_log_view.set_editable(false);
    runtime_log_view.set_cursor_visible(false);
    runtime_log_view.set_monospace(true);
    runtime_log_view.set_wrap_mode(gtk::WrapMode::None);
    runtime_log_view.add_css_class("log-view");
    let runtime_log_scroll = ScrolledWindow::builder()
        .hexpand(true)
        .vexpand(true)
        .child(&runtime_log_view)
        .build();
    runtime_log_scroll.add_css_class("file-pane");
    runtime_box.append(&runtime_title);
    runtime_box.append(&runtime_log_scroll);

    let crash_box = GtkBox::new(Orientation::Vertical, 6);
    let crash_title = Label::new(Some("Crash log — crash.log"));
    crash_title.set_xalign(0.0);
    crash_title.add_css_class("panel-title");
    let crash_log_view = TextView::new();
    crash_log_view.set_editable(false);
    crash_log_view.set_cursor_visible(false);
    crash_log_view.set_monospace(true);
    crash_log_view.set_wrap_mode(gtk::WrapMode::None);
    crash_log_view.add_css_class("log-view");
    let crash_log_scroll = ScrolledWindow::builder()
        .hexpand(true)
        .vexpand(true)
        .child(&crash_log_view)
        .build();
    crash_log_scroll.add_css_class("file-pane");
    crash_box.append(&crash_title);
    crash_box.append(&crash_log_scroll);

    log_panes.set_start_child(Some(&runtime_box));
    log_panes.set_end_child(Some(&crash_box));
    log_panes.set_resize_start_child(true);
    log_panes.set_resize_end_child(true);
    logs_page.append(&log_panes);

    let logs_note = Label::new(Some(
        "Runtime logging records BoxHop actions, connection results and errors, but never saved passwords or the vault key. Rust panics include a backtrace in crash.log. An unclean exit also leaves a session marker that is recorded as a crash on the next launch.",
    ));
    logs_note.set_xalign(0.0);
    logs_note.set_wrap(true);
    logs_note.add_css_class("muted");
    logs_page.append(&logs_note);
    stack.add_named(&logs_page, Some("logs"));
    refresh_log_views(&runtime_log_view, &crash_log_view);

    // Asset editor page
    let asset_page = GtkBox::new(Orientation::Vertical, 12);
    asset_page.add_css_class("panel");
    let asset_title = Label::new(Some("Asset settings"));
    asset_title.set_xalign(0.0);
    asset_title.add_css_class("page-title");
    asset_page.append(&asset_title);

    // Boop-Crypt-style credential vault: a random vault key is wrapped by the
    // master password. Individual asset secret blobs are encrypted by that
    // random key. The master password itself is never written to disk.
    let vault_box = GtkBox::new(Orientation::Vertical, 8);
    vault_box.add_css_class("vault-box");
    let vault_status = Label::new(Some(if vault_exists() {
        "Credential vault: locked"
    } else {
        "Credential vault: not created"
    }));
    vault_status.set_xalign(0.0);
    vault_status.add_css_class("panel-title");
    vault_box.append(&vault_status);

    let vault_row = GtkBox::new(Orientation::Horizontal, 8);
    let vault_password = Entry::builder()
        .placeholder_text("Vault master password")
        .hexpand(true)
        .build();
    vault_password.set_visibility(false);
    let vault_confirm = Entry::builder()
        .placeholder_text("Confirm master password (first creation only)")
        .hexpand(true)
        .build();
    vault_confirm.set_visibility(false);
    let vault_unlock_btn = styled_button(if vault_exists() { "Unlock vault" } else { "Create vault" });
    let vault_lock_btn = styled_button("Lock vault");
    vault_row.append(&vault_password);
    vault_row.append(&vault_confirm);
    vault_row.append(&vault_unlock_btn);
    vault_row.append(&vault_lock_btn);
    vault_box.append(&vault_row);
    let vault_note = Label::new(Some(
        "Passwords are stored in encrypted per-asset GnuPG AES-256 blobs. The master password only wraps the separate random vault key and is never saved.",
    ));
    vault_note.set_xalign(0.0);
    vault_note.set_wrap(true);
    vault_note.add_css_class("muted");
    vault_box.append(&vault_note);
    asset_page.append(&vault_box);

    let grid = Grid::new();
    grid.set_column_spacing(12);
    grid.set_row_spacing(10);
    grid.set_hexpand(true);

    let make_entry = |placeholder: &str| Entry::builder().placeholder_text(placeholder).hexpand(true).build();
    let name = make_entry("Asset name");
    let host = make_entry("Host / IP");
    let mac = make_entry("MAC address (AA:BB:CC:DD:EE:FF)");
    let username = make_entry("SSH username");
    let ssh_password = make_entry("SSH password (encrypted when vault is unlocked)");
    ssh_password.set_visibility(false);
    let ssh_port = make_entry("SSH port");
    let transfer_port = make_entry("SFTP port");
    let ftp_username = make_entry("FTP username");
    let ftp_password = make_entry("FTP password (encrypted when vault is unlocked)");
    ftp_password.set_visibility(false);
    let ftp_port = make_entry("FTP port");
    let local_path = make_entry("Default local directory");
    let remote_path = make_entry("Default remote directory");
    let auto_connect = CheckButton::with_label("Auto-connect SSH when this asset is selected");
    let rdp_username = make_entry("RDP username");
    let rdp_password = make_entry("RDP password (encrypted when vault is unlocked)");
    rdp_password.set_visibility(false);
    let rdp_domain = make_entry("RDP domain (optional)");
    let rdp_port = make_entry("RDP port");
    let rdp_dynamic_resolution = CheckButton::with_label("Dynamic resolution");
    let rdp_clipboard = CheckButton::with_label("Clipboard redirection");
    let rdp_tofu = CheckButton::with_label("Trust RDP certificate on first use (TOFU)");

    let rows: [(&str, &Entry); 16] = [
        ("Name", &name),
        ("Host / IP", &host),
        ("MAC", &mac),
        ("SSH username", &username),
        ("SSH password", &ssh_password),
        ("SSH port", &ssh_port),
        ("SFTP port", &transfer_port),
        ("FTP username", &ftp_username),
        ("FTP password", &ftp_password),
        ("FTP port", &ftp_port),
        ("Local path", &local_path),
        ("Remote path", &remote_path),
        ("RDP username", &rdp_username),
        ("RDP password", &rdp_password),
        ("RDP domain", &rdp_domain),
        ("RDP port", &rdp_port),
    ];
    for (row, (label_text, entry)) in rows.iter().enumerate() {
        let label = Label::new(Some(label_text));
        label.set_xalign(0.0);
        label.add_css_class("field-label");
        grid.attach(&label, 0, row as i32, 1, 1);
        grid.attach(*entry, 1, row as i32, 1, 1);
    }

    let test_ssh_btn = styled_button("Test SSH");
    let test_ftp_btn = styled_button("Test FTP");
    let test_rdp_btn = styled_button("Test RDP");
    grid.attach(&test_ssh_btn, 2, 5, 1, 1);
    grid.attach(&test_ftp_btn, 2, 9, 1, 1);
    grid.attach(&test_rdp_btn, 2, 15, 1, 1);

    grid.attach(&auto_connect, 1, 16, 2, 1);
    grid.attach(&rdp_dynamic_resolution, 1, 17, 2, 1);
    grid.attach(&rdp_clipboard, 1, 18, 2, 1);
    grid.attach(&rdp_tofu, 1, 19, 2, 1);
    asset_page.append(&grid);

    let test_note = Label::new(Some(
        "Each Test button first checks the configured TCP port, then performs a real protocol/authentication test when credentials are available.",
    ));
    test_note.set_xalign(0.0);
    test_note.set_wrap(true);
    test_note.add_css_class("muted");
    asset_page.append(&test_note);

    let asset_actions = GtkBox::new(Orientation::Horizontal, 8);
    let save_asset_btn = styled_icon_button("Save asset", "document-save-symbolic");
    save_asset_btn.add_css_class("primary");
    let delete_asset_btn = styled_icon_button("Delete asset", "edit-delete-symbolic");
    delete_asset_btn.add_css_class("danger");
    asset_actions.append(&save_asset_btn);
    asset_actions.append(&delete_asset_btn);
    asset_page.append(&asset_actions);

    let asset_scroll = ScrolledWindow::builder()
        .hexpand(true)
        .vexpand(true)
        .child(&asset_page)
        .build();
    stack.add_named(&asset_scroll, Some("asset"));

    let editor = AssetEditor {
        name,
        host,
        mac,
        username,
        ssh_password,
        ssh_port,
        transfer_port,
        ftp_username,
        ftp_password,
        ftp_port,
        local_path,
        remote_path,
        auto_connect,
        rdp_username,
        rdp_password,
        rdp_domain,
        rdp_port,
        rdp_dynamic_resolution,
        rdp_clipboard,
        rdp_tofu,
    };
    set_secret_editor_sensitive(&editor, false);

    content.append(&stack);
    root.append(&sidebar);
    root.append(&content);
    window.set_child(Some(&root));

    rebuild_asset_list(&asset_list, &assets.borrow(), None);

    // Tab switching
    {
        let stack = stack.clone();
        let terminal_btn_c = terminal_btn.clone();
        let files_btn_c = files_btn.clone();
        let rdp_btn_c = rdp_btn.clone();
        let logs_btn_c = logs_btn.clone();
        let asset_btn_c = asset_btn.clone();
        terminal_btn.connect_clicked(move |_| {
            stack.set_visible_child_name("terminal");
            set_active_tool(&terminal_btn_c, &[&terminal_btn_c, &files_btn_c, &rdp_btn_c, &logs_btn_c, &asset_btn_c]);
        });
    }
    {
        let stack = stack.clone();
        let terminal_btn_c = terminal_btn.clone();
        let files_btn_c = files_btn.clone();
        let rdp_btn_c = rdp_btn.clone();
        let logs_btn_c = logs_btn.clone();
        let asset_btn_c = asset_btn.clone();
        files_btn.connect_clicked(move |_| {
            stack.set_visible_child_name("files");
            set_active_tool(&files_btn_c, &[&terminal_btn_c, &files_btn_c, &rdp_btn_c, &logs_btn_c, &asset_btn_c]);
        });
    }
    {
        let stack = stack.clone();
        let terminal_btn_c = terminal_btn.clone();
        let files_btn_c = files_btn.clone();
        let rdp_btn_c = rdp_btn.clone();
        let logs_btn_c = logs_btn.clone();
        let asset_btn_c = asset_btn.clone();
        rdp_btn.connect_clicked(move |_| {
            stack.set_visible_child_name("rdp");
            set_active_tool(&rdp_btn_c, &[&terminal_btn_c, &files_btn_c, &rdp_btn_c, &logs_btn_c, &asset_btn_c]);
        });
    }
    {
        let stack = stack.clone();
        let terminal_btn_c = terminal_btn.clone();
        let files_btn_c = files_btn.clone();
        let rdp_btn_c = rdp_btn.clone();
        let logs_btn_c = logs_btn.clone();
        let asset_btn_c = asset_btn.clone();
        let runtime_log_view_c = runtime_log_view.clone();
        let crash_log_view_c = crash_log_view.clone();
        logs_btn.connect_clicked(move |_| {
            refresh_log_views(&runtime_log_view_c, &crash_log_view_c);
            stack.set_visible_child_name("logs");
            set_active_tool(&logs_btn_c, &[&terminal_btn_c, &files_btn_c, &rdp_btn_c, &logs_btn_c, &asset_btn_c]);
        });
    }
    {
        let stack = stack.clone();
        let terminal_btn_c = terminal_btn.clone();
        let files_btn_c = files_btn.clone();
        let rdp_btn_c = rdp_btn.clone();
        let logs_btn_c = logs_btn.clone();
        let asset_btn_c = asset_btn.clone();
        asset_btn.connect_clicked(move |_| {
            stack.set_visible_child_name("asset");
            set_active_tool(&asset_btn_c, &[&terminal_btn_c, &files_btn_c, &rdp_btn_c, &logs_btn_c, &asset_btn_c]);
        });
    }

    {
        let runtime_log_view = runtime_log_view.clone();
        let crash_log_view = crash_log_view.clone();
        logs_refresh_btn.connect_clicked(move |_| {
            refresh_log_views(&runtime_log_view, &crash_log_view);
        });
    }
    {
        let stack = stack.clone();
        let runtime_log_view = runtime_log_view.clone();
        let crash_log_view = crash_log_view.clone();
        glib::timeout_add_local(Duration::from_secs(1), move || {
            let logs_visible = stack
                .visible_child_name()
                .map(|name| name.as_str() == "logs")
                .unwrap_or(false);
            if logs_visible {
                refresh_log_views(&runtime_log_view, &crash_log_view);
            }
            glib::ControlFlow::Continue
        });
    }

    // Credential vault create/unlock.
    {
        let vault_key = vault_key.clone();
        let vault_status = vault_status.clone();
        let vault_password = vault_password.clone();
        let vault_confirm = vault_confirm.clone();
        let vault_unlock_btn = vault_unlock_btn.clone();
        let assets = assets.clone();
        let selected = selected.clone();
        let editor = editor.clone();
        let status = status.clone();
        vault_unlock_btn.clone().connect_clicked(move |_| {
            let password = vault_password.text().to_string();
            let result = if vault_exists() {
                unlock_vault(&password)
            } else {
                let confirm = vault_confirm.text().to_string();
                if password != confirm {
                    set_status(&status, "Vault passwords do not match", "status-error");
                    return;
                }
                create_vault(&password)
            };

            match result {
                Ok(key) => {
                    *vault_key.borrow_mut() = Some(key.clone());
                    set_secret_editor_sensitive(&editor, true);
                    vault_status.set_text("Credential vault: unlocked");
                    vault_unlock_btn.set_label("Unlock vault");
                    vault_password.set_text("");
                    vault_confirm.set_text("");
                    if let Some(asset) = selected_asset(&assets, &selected) {
                        match load_asset_secrets(asset.id, &key) {
                            Ok(secrets) => fill_secret_editor(&editor, &secrets),
                            Err(err) => {
                                clear_secret_editor(&editor);
                                set_status(&status, &format!("Vault unlocked, but credentials could not be read: {err}"), "status-error");
                                return;
                            }
                        }
                    }
                    set_status(&status, "● Credential vault unlocked", "status-online");
                }
                Err(err) => set_status(&status, &format!("Vault: {err}"), "status-error"),
            }
        });
    }

    // Lock the in-memory vault key and remove decrypted passwords from the UI.
    {
        let vault_key = vault_key.clone();
        let vault_status = vault_status.clone();
        let editor = editor.clone();
        let status = status.clone();
        vault_lock_btn.connect_clicked(move |_| {
            if let Some(mut key) = vault_key.borrow_mut().take() {
                key.clear();
            }
            clear_secret_editor(&editor);
            set_secret_editor_sensitive(&editor, false);
            vault_status.set_text(if vault_exists() {
                "Credential vault: locked"
            } else {
                "Credential vault: not created"
            });
            set_status(&status, "● Credential vault locked", "status-neutral");
        });
    }

    // Add asset
    {
        let assets = assets.clone();
        let selected = selected.clone();
        let list = asset_list.clone();
        let stack = stack.clone();
        let editor = editor.clone();
        let terminal_btn_c = terminal_btn.clone();
        let files_btn_c = files_btn.clone();
        let rdp_btn_c = rdp_btn.clone();
        let logs_btn_c = logs_btn.clone();
        let asset_btn_c = asset_btn.clone();
        add_asset.connect_clicked(move |_| {
            let selected_idx = {
                let mut assets_mut = assets.borrow_mut();
                assets_mut.push(Asset::default());
                assets_mut.len() - 1
            };
            *selected.borrow_mut() = Some(selected_idx);
            let snapshot = assets.borrow().clone();
            save_assets(&snapshot);
            rebuild_asset_list(&list, &snapshot, Some(selected_idx));
            fill_editor(&editor, &snapshot[selected_idx]);
            clear_secret_editor(&editor);
            stack.set_visible_child_name("asset");
            set_active_tool(&asset_btn_c, &[&terminal_btn_c, &files_btn_c, &rdp_btn_c, &logs_btn_c, &asset_btn_c]);
        });
    }

    // Selection changes populate every page.
    {
        let assets = assets.clone();
        let selected = selected.clone();
        let editor = editor.clone();
        let terminal_header = terminal_header.clone();
        let local_path_view = local_path_view.clone();
        let remote_path_view = remote_path_view.clone();
        let rdp_summary = rdp_summary.clone();
        let rdp_info = rdp_info.clone();
        let status = status.clone();
        let terminal = terminal.clone();
        let terminal_busy = terminal_busy.clone();
        let current_local_path = current_local_path.clone();
        let current_remote_path = current_remote_path.clone();
        let local_items = local_items.clone();
        let local_list = local_list.clone();
        let vault_key = vault_key.clone();
        asset_list.connect_row_selected(move |_, row| {
            let Some(row) = row else { return; };
            let idx = row.index() as usize;
            *selected.borrow_mut() = Some(idx);
            let asset = assets.borrow().get(idx).cloned();
            let Some(asset) = asset else { return; };

            fill_editor(&editor, &asset);
            clear_secret_editor(&editor);
            let mut credential_error = None::<String>;
            if let Some(key) = vault_key.borrow().clone() {
                match load_asset_secrets(asset.id, &key) {
                    Ok(secrets) => fill_secret_editor(&editor, &secrets),
                    Err(err) => credential_error = Some(err.to_string()),
                }
            }
            terminal_header.set_text(&format!("Terminal — {}", asset.name));
            let local_start = if asset.local_path.trim().is_empty() { local_home() } else { asset.local_path.clone() };
            let remote_start = if asset.remote_path.trim().is_empty() { ".".to_string() } else { asset.remote_path.clone() };
            *current_local_path.borrow_mut() = local_start.clone();
            *current_remote_path.borrow_mut() = remote_start.clone();
            local_path_view.set_text(&local_start);
            remote_path_view.set_text(&remote_start);
            match list_local(&local_start) {
                Ok(items) => {
                    *local_items.borrow_mut() = items.clone();
                    rebuild_file_list(&local_list, &items);
                }
                Err(err) => set_status(&status, &format!("Local files: {err}"), "status-error"),
            }
            rdp_summary.set_text(&format!("{} — {}:{}", asset.name, if asset.host.is_empty() { "host not configured" } else { &asset.host }, asset.rdp_port));
            let client_text = find_rdp_client()
                .map(|p| format!("RDP client detected: {}", p.display()))
                .unwrap_or_else(|| "RDP client not detected in this native development environment".into());
            rdp_info.set_text(&client_text);
            if let Some(err) = credential_error {
                set_status(&status, &format!("Credential read failed: {err}"), "status-error");
            } else {
                set_status(&status, "● Selected — press Check", "status-neutral");
            }

            if asset.auto_connect && !asset.host.is_empty() {
                if let Some(ssh) = find_program(&["ssh"]) {
                    let argv = vec![
                        ssh.to_string_lossy().into_owned(),
                        "-p".into(),
                        asset.ssh_port.to_string(),
                        ssh_target(&asset),
                    ];
                    spawn_terminal_command(
                        &terminal,
                        argv,
                        &terminal_busy,
                        &terminal_header,
                        &status,
                        &format!("SSH — {}", asset.name),
                    );
                } else {
                    set_status(&status, "OpenSSH client not found in PATH", "status-error");
                }
            }
        });
    }

    // Save asset
    {
        let assets = assets.clone();
        let selected = selected.clone();
        let editor = editor.clone();
        let list = asset_list.clone();
        let status = status.clone();
        let vault_key = vault_key.clone();
        save_asset_btn.connect_clicked(move |_| {
            let Some(idx) = *selected.borrow() else {
                set_status(&status, "Select or add an asset first", "status-error");
                return;
            };
            let existing_id = assets.borrow().get(idx).map(|a| a.id).unwrap_or_else(Uuid::new_v4);
            let updated = asset_from_editor(&editor, existing_id);
            {
                let mut asset_vec = assets.borrow_mut();
                if let Some(slot) = asset_vec.get_mut(idx) {
                    *slot = updated;
                }
            }
            let snapshot = assets.borrow().clone();
            save_assets(&snapshot);
            if let Some(key) = vault_key.borrow().clone() {
                let secrets = secrets_from_editor(&editor);
                if let Err(err) = save_asset_secrets(existing_id, &secrets, &key) {
                    rebuild_asset_list(&list, &snapshot, Some(idx));
                    set_status(&status, &format!("Asset saved, but encrypted credentials failed: {err}"), "status-error");
                    return;
                }
            }
            rebuild_asset_list(&list, &snapshot, Some(idx));
            set_status(&status, if vault_key.borrow().is_some() {
                "● Asset + encrypted credentials saved"
            } else {
                "● Asset saved (vault locked; credentials unchanged)"
            }, "status-online");
        });
    }

    // Delete asset with confirmation.
    {
        let window = window.clone();
        let assets = assets.clone();
        let selected = selected.clone();
        let list = asset_list.clone();
        let editor = editor.clone();
        let status = status.clone();
        delete_asset_btn.connect_clicked(move |_| {
            let Some(idx) = *selected.borrow() else {
                set_status(&status, "No asset selected", "status-error");
                return;
            };
            let (asset_name, asset_id) = assets.borrow().get(idx)
                .map(|a| (a.name.clone(), a.id))
                .unwrap_or_else(|| (String::new(), Uuid::nil()));
            let dialog = confirmation_dialog(
                &window,
                &format!("Delete ‘{}’?", asset_name),
                "This removes the saved asset definition. It does not change the remote computer.",
            );

            let assets = assets.clone();
            let selected = selected.clone();
            let list = list.clone();
            let editor = editor.clone();
            let status = status.clone();
            dialog.connect_response(move |dialog, response| {
                if response == ResponseType::Accept {
                    {
                        let mut asset_vec = assets.borrow_mut();
                        if idx < asset_vec.len() {
                            asset_vec.remove(idx);
                        }
                    }
                    if asset_id != Uuid::nil() {
                        delete_asset_secrets(asset_id);
                    }
                    *selected.borrow_mut() = None;
                    let snapshot = assets.borrow().clone();
                    save_assets(&snapshot);
                    rebuild_asset_list(&list, &snapshot, None);
                    clear_editor(&editor);
                    set_status(&status, "● Asset deleted", "status-neutral");
                }
                dialog.close();
            });
            dialog.present();
        });
    }

    // Per-protocol connection tests from the current Asset form.
    // All network/authentication work runs off GTK's main thread so a slow host,
    // first-use SSH host-key write, failed authentication, or RDP negotiation
    // cannot make the BoxHop window appear to hang.
    {
        let assets = assets.clone();
        let selected = selected.clone();
        let editor = editor.clone();
        let status = status.clone();
        test_ssh_btn.connect_clicked(move |button| {
            let id = selected_asset(&assets, &selected).map(|a| a.id).unwrap_or_else(Uuid::new_v4);
            let asset = asset_from_editor(&editor, id);
            let password = editor.ssh_password.text().to_string();
            button.set_sensitive(false);
            set_status(&status, "● Testing SSH port + authentication…", "status-neutral");

            let status_done = status.clone();
            let button_done = button.clone();
            run_background(
                move || test_ssh_connection(&asset, &password),
                move |result| {
                    button_done.set_sensitive(true);
                    match result {
                        Ok(message) => set_status(&status_done, &format!("● {message}"), "status-online"),
                        Err(err) => set_status(&status_done, &format!("SSH test failed: {err}"), "status-error"),
                    }
                },
            );
        });
    }

    {
        let assets = assets.clone();
        let selected = selected.clone();
        let editor = editor.clone();
        let status = status.clone();
        test_ftp_btn.connect_clicked(move |button| {
            let id = selected_asset(&assets, &selected).map(|a| a.id).unwrap_or_else(Uuid::new_v4);
            let asset = asset_from_editor(&editor, id);
            let password = editor.ftp_password.text().to_string();
            button.set_sensitive(false);
            set_status(&status, "● Testing FTP port + login…", "status-neutral");

            let status_done = status.clone();
            let button_done = button.clone();
            run_background(
                move || test_ftp_connection(&asset, &password),
                move |result| {
                    button_done.set_sensitive(true);
                    match result {
                        Ok(message) => set_status(&status_done, &format!("● {message}"), "status-online"),
                        Err(err) => set_status(&status_done, &format!("FTP test failed: {err}"), "status-error"),
                    }
                },
            );
        });
    }

    {
        let assets = assets.clone();
        let selected = selected.clone();
        let editor = editor.clone();
        let status = status.clone();
        test_rdp_btn.connect_clicked(move |button| {
            let id = selected_asset(&assets, &selected).map(|a| a.id).unwrap_or_else(Uuid::new_v4);
            let asset = asset_from_editor(&editor, id);
            let password = editor.rdp_password.text().to_string();
            button.set_sensitive(false);
            set_status(&status, "● Testing RDP port + authentication…", "status-neutral");

            let status_done = status.clone();
            let button_done = button.clone();
            run_background(
                move || test_rdp_connection(&asset, &password),
                move |result| {
                    button_done.set_sensitive(true);
                    match result {
                        Ok(message) => set_status(&status_done, &format!("● {message}"), "status-online"),
                        Err(err) => set_status(&status_done, &format!("RDP test failed: {err}"), "status-error"),
                    }
                },
            );
        });
    }

    // Online check
    {
        let assets = assets.clone();
        let selected = selected.clone();
        let status = status.clone();
        let editor = editor.clone();
        check_btn.connect_clicked(move |button| {
            let Some(asset) = current_asset_from_editor(&assets, &selected, &editor) else {
                set_status(&status, "● No asset selected", "status-error");
                return;
            };
            button.set_sensitive(false);
            set_status(&status, "● Checking…", "status-neutral");

            let status_done = status.clone();
            let button_done = button.clone();
            run_background(
                move || check_asset(&asset),
                move |result| {
                    button_done.set_sensitive(true);
                    match result {
                        Ok(_) => set_status(&status_done, "● Online (SSH port)", "status-online"),
                        Err(err) => set_status(&status_done, &format!("● Offline: {err}"), "status-offline"),
                    }
                },
            );
        });
    }

    // Wake-on-LAN
    {
        let assets = assets.clone();
        let selected = selected.clone();
        let status = status.clone();
        let editor = editor.clone();
        wol_btn.connect_clicked(move |_| {
            let Some(asset) = current_asset_from_editor(&assets, &selected, &editor) else {
                set_status(&status, "Select an asset first", "status-error");
                return;
            };
            match wake_on_lan(&asset.mac) {
                Ok(_) => set_status(&status, "● Wake packet sent", "status-online"),
                Err(err) => set_status(&status, &format!("Wake failed: {err}"), "status-error"),
            }
        });
    }

    // Remote file protocol selector.
    {
        let remote_protocol = remote_protocol.clone();
        let files_title = files_title.clone();
        let sftp_mode_btn_c = sftp_mode_btn.clone();
        let ftp_mode_btn_c = ftp_mode_btn.clone();
        let remote_list = remote_list.clone();
        let remote_items = remote_items.clone();
        let status = status.clone();
        sftp_mode_btn.connect_clicked(move |_| {
            *remote_protocol.borrow_mut() = RemoteProtocol::Sftp;
            set_active_tool(&sftp_mode_btn_c, &[&sftp_mode_btn_c, &ftp_mode_btn_c]);
            files_title.set_text("Files — SFTP dual-pane browser");
            remote_items.borrow_mut().clear();
            rebuild_file_list(&remote_list, &[]);
            set_status(&status, "SFTP selected — press Refresh", "status-neutral");
        });
    }

    {
        let remote_protocol = remote_protocol.clone();
        let files_title = files_title.clone();
        let sftp_mode_btn_c = sftp_mode_btn.clone();
        let ftp_mode_btn_c = ftp_mode_btn.clone();
        let remote_list = remote_list.clone();
        let remote_items = remote_items.clone();
        let status = status.clone();
        ftp_mode_btn.connect_clicked(move |_| {
            *remote_protocol.borrow_mut() = RemoteProtocol::Ftp;
            set_active_tool(&ftp_mode_btn_c, &[&sftp_mode_btn_c, &ftp_mode_btn_c]);
            files_title.set_text("Files — FTP dual-pane browser");
            remote_items.borrow_mut().clear();
            rebuild_file_list(&remote_list, &[]);
            set_status(&status, "FTP selected — press Refresh", "status-neutral");
        });
    }

    // SFTP/FTP/local dual-pane file browser.
    // Remote/network operations always run off the GTK thread. A slow FTP/SFTP
    // server must never make the entire BoxHop window appear "Not Responding".
    {
        let assets = assets.clone();
        let selected = selected.clone();
        let status = status.clone();
        let local_path_view = local_path_view.clone();
        let remote_path_view = remote_path_view.clone();
        let local_list = local_list.clone();
        let remote_list = remote_list.clone();
        let local_items = local_items.clone();
        let remote_items = remote_items.clone();
        let current_local_path = current_local_path.clone();
        let current_remote_path = current_remote_path.clone();
        let remote_protocol = remote_protocol.clone();
        let editor = editor.clone();
        files_refresh_btn.connect_clicked(move |button| {
            let local_path = {
                let typed = local_path_view.text().trim().to_string();
                if typed.is_empty() { local_home() } else { typed }
            };
            *current_local_path.borrow_mut() = local_path.clone();
            local_path_view.set_text(&local_path);
            match list_local(&local_path) {
                Ok(items) => {
                    *local_items.borrow_mut() = items.clone();
                    rebuild_file_list(&local_list, &items);
                }
                Err(err) => {
                    set_status(&status, &format!("Local files: {err}"), "status-error");
                    return;
                }
            }

            let Some(asset) = current_asset_from_editor(&assets, &selected, &editor) else {
                set_status(&status, "Local files refreshed; select an asset for remote files", "status-neutral");
                return;
            };
            let remote_path = {
                let typed = remote_path_view.text().trim().to_string();
                if typed.is_empty() { ".".to_string() } else { typed }
            };
            *current_remote_path.borrow_mut() = remote_path.clone();
            remote_path_view.set_text(&remote_path);
            let protocol = *remote_protocol.borrow();
            let password = editor.ftp_password.text().to_string();
            let asset_id = asset.id;

            button.set_sensitive(false);
            set_file_list_message(&remote_list, &format!("Refreshing {}…", protocol.label()));
            set_status(&status, &format!("● Refreshing {}…", protocol.label()), "status-neutral");

            let button_done = button.clone();
            let assets_done = assets.clone();
            let selected_done = selected.clone();
            let status_done = status.clone();
            let remote_path_view_done = remote_path_view.clone();
            let remote_list_done = remote_list.clone();
            let remote_items_done = remote_items.clone();
            let current_remote_path_done = current_remote_path.clone();
            let remote_protocol_done = remote_protocol.clone();
            run_background(
                move || list_remote_by_protocol(protocol, &asset, &password, &remote_path),
                move |result| {
                    button_done.set_sensitive(true);
                    let still_selected = selected_asset(&assets_done, &selected_done)
                        .map(|a| a.id == asset_id)
                        .unwrap_or(false);
                    if !still_selected || *remote_protocol_done.borrow() != protocol {
                        return;
                    }
                    match result {
                        Ok(listing) => {
                            *current_remote_path_done.borrow_mut() = listing.path.clone();
                            remote_path_view_done.set_text(&listing.path);
                            *remote_items_done.borrow_mut() = listing.items.clone();
                            rebuild_file_list(&remote_list_done, &listing.items);
                            let count = listing.items.len();
                            let suffix = if count == 0 {
                                "0 items — directory is empty or this FTP account cannot see entries".to_string()
                            } else {
                                format!("{count} item{}", if count == 1 { "" } else { "s" })
                            };
                            set_status(
                                &status_done,
                                &format!("● {} refreshed — {} — {suffix}", protocol.label(), listing.path),
                                "status-online",
                            );
                        }
                        Err(err) => {
                            set_file_list_message(&remote_list_done, "Remote listing failed");
                            set_status(&status_done, &format!("{}: {err}", protocol.label()), "status-error");
                        }
                    }
                },
            );
        });
    }

    {
        let status = status.clone();
        let local_path_view = local_path_view.clone();
        let local_list = local_list.clone();
        let local_items = local_items.clone();
        let current_local_path = current_local_path.clone();
        local_up_btn.connect_clicked(move |_| {
            let current = PathBuf::from(current_local_path.borrow().as_str());
            let parent = current.parent().map(|p| p.to_path_buf()).unwrap_or_else(|| PathBuf::from("/"));
            let parent_text = parent.to_string_lossy().into_owned();
            match list_local(&parent_text) {
                Ok(items) => {
                    *current_local_path.borrow_mut() = parent_text.clone();
                    local_path_view.set_text(&parent_text);
                    *local_items.borrow_mut() = items.clone();
                    rebuild_file_list(&local_list, &items);
                    set_status(&status, "● Local folder changed", "status-neutral");
                }
                Err(err) => set_status(&status, &format!("Local files: {err}"), "status-error"),
            }
        });
    }

    {
        let assets = assets.clone();
        let selected = selected.clone();
        let status = status.clone();
        let remote_path_view = remote_path_view.clone();
        let remote_list = remote_list.clone();
        let remote_items = remote_items.clone();
        let current_remote_path = current_remote_path.clone();
        let remote_protocol = remote_protocol.clone();
        let editor = editor.clone();
        remote_up_btn.connect_clicked(move |button| {
            let Some(asset) = current_asset_from_editor(&assets, &selected, &editor) else {
                set_status(&status, "Select an asset first", "status-error");
                return;
            };
            let current_remote = current_remote_path.borrow().clone();
            let parent = remote_parent(&current_remote);
            let protocol = *remote_protocol.borrow();
            let password = editor.ftp_password.text().to_string();
            let asset_id = asset.id;
            button.set_sensitive(false);
            set_file_list_message(&remote_list, &format!("Opening {parent}…"));
            set_status(&status, &format!("● Opening {} folder…", protocol.label()), "status-neutral");

            let button_done = button.clone();
            let assets_done = assets.clone();
            let selected_done = selected.clone();
            let status_done = status.clone();
            let remote_path_view_done = remote_path_view.clone();
            let remote_list_done = remote_list.clone();
            let remote_items_done = remote_items.clone();
            let current_remote_path_done = current_remote_path.clone();
            let remote_protocol_done = remote_protocol.clone();
            run_background(
                move || list_remote_by_protocol(protocol, &asset, &password, &parent),
                move |result| {
                    button_done.set_sensitive(true);
                    let still_selected = selected_asset(&assets_done, &selected_done)
                        .map(|a| a.id == asset_id)
                        .unwrap_or(false);
                    if !still_selected || *remote_protocol_done.borrow() != protocol {
                        return;
                    }
                    match result {
                        Ok(listing) => {
                            *current_remote_path_done.borrow_mut() = listing.path.clone();
                            remote_path_view_done.set_text(&listing.path);
                            *remote_items_done.borrow_mut() = listing.items.clone();
                            rebuild_file_list(&remote_list_done, &listing.items);
                            set_status(
                                &status_done,
                                &format!("● {} folder changed — {} items", protocol.label(), listing.items.len()),
                                "status-neutral",
                            );
                        }
                        Err(err) => {
                            set_file_list_message(&remote_list_done, "Remote listing failed");
                            set_status(&status_done, &format!("{}: {err}", protocol.label()), "status-error");
                        }
                    }
                },
            );
        });
    }

    {
        let status = status.clone();
        let local_path_view = local_path_view.clone();
        let local_list_c = local_list.clone();
        let local_items = local_items.clone();
        let current_local_path = current_local_path.clone();
        local_list.connect_row_activated(move |_, row| {
            let idx = row.index() as usize;
            let item = { local_items.borrow().get(idx).cloned() };
            let Some(item) = item else { return; };
            if !item.is_dir {
                return;
            }
            let next = PathBuf::from(current_local_path.borrow().as_str()).join(&item.name);
            let next_text = next.to_string_lossy().into_owned();
            match list_local(&next_text) {
                Ok(items) => {
                    *current_local_path.borrow_mut() = next_text.clone();
                    local_path_view.set_text(&next_text);
                    *local_items.borrow_mut() = items.clone();
                    rebuild_file_list(&local_list_c, &items);
                    set_status(&status, "● Local folder opened", "status-neutral");
                }
                Err(err) => set_status(&status, &format!("Local files: {err}"), "status-error"),
            }
        });
    }

    {
        let assets = assets.clone();
        let selected = selected.clone();
        let status = status.clone();
        let remote_path_view = remote_path_view.clone();
        let remote_list_c = remote_list.clone();
        let remote_items = remote_items.clone();
        let current_remote_path = current_remote_path.clone();
        let remote_protocol = remote_protocol.clone();
        let editor = editor.clone();
        remote_list.connect_row_activated(move |_, row| {
            let idx = row.index() as usize;
            let item = { remote_items.borrow().get(idx).cloned() };
            let Some(item) = item else { return; };
            if !item.is_dir {
                return;
            }
            let Some(asset) = current_asset_from_editor(&assets, &selected, &editor) else { return; };
            let current_remote = current_remote_path.borrow().clone();
            let next = join_remote(&current_remote, &item.name);
            let protocol = *remote_protocol.borrow();
            let password = editor.ftp_password.text().to_string();
            let asset_id = asset.id;
            set_file_list_message(&remote_list_c, &format!("Opening {next}…"));
            set_status(&status, &format!("● Opening {} folder…", protocol.label()), "status-neutral");

            let assets_done = assets.clone();
            let selected_done = selected.clone();
            let status_done = status.clone();
            let remote_path_view_done = remote_path_view.clone();
            let remote_list_done = remote_list_c.clone();
            let remote_items_done = remote_items.clone();
            let current_remote_path_done = current_remote_path.clone();
            let remote_protocol_done = remote_protocol.clone();
            run_background(
                move || list_remote_by_protocol(protocol, &asset, &password, &next),
                move |result| {
                    let still_selected = selected_asset(&assets_done, &selected_done)
                        .map(|a| a.id == asset_id)
                        .unwrap_or(false);
                    if !still_selected || *remote_protocol_done.borrow() != protocol {
                        return;
                    }
                    match result {
                        Ok(listing) => {
                            *current_remote_path_done.borrow_mut() = listing.path.clone();
                            remote_path_view_done.set_text(&listing.path);
                            *remote_items_done.borrow_mut() = listing.items.clone();
                            rebuild_file_list(&remote_list_done, &listing.items);
                            set_status(
                                &status_done,
                                &format!("● {} folder opened — {} items", protocol.label(), listing.items.len()),
                                "status-neutral",
                            );
                        }
                        Err(err) => {
                            set_file_list_message(&remote_list_done, "Remote listing failed");
                            set_status(&status_done, &format!("{}: {err}", protocol.label()), "status-error");
                        }
                    }
                },
            );
        });
    }

    {
        let assets = assets.clone();
        let selected = selected.clone();
        let status = status.clone();
        let local_list = local_list.clone();
        let remote_list = remote_list.clone();
        let local_items = local_items.clone();
        let remote_items = remote_items.clone();
        let current_local_path = current_local_path.clone();
        let current_remote_path = current_remote_path.clone();
        let remote_path_view = remote_path_view.clone();
        let remote_protocol = remote_protocol.clone();
        let editor = editor.clone();
        upload_btn.connect_clicked(move |button| {
            let Some(row) = local_list.selected_row() else {
                set_status(&status, "Select a local file or folder to upload", "status-error");
                return;
            };
            let item = { local_items.borrow().get(row.index() as usize).cloned() };
            let Some(item) = item else { return; };
            let Some(asset) = current_asset_from_editor(&assets, &selected, &editor) else {
                set_status(&status, "Select an asset first", "status-error");
                return;
            };
            let local_path = current_local_path.borrow().clone();
            let remote_path = current_remote_path.borrow().clone();
            let protocol = *remote_protocol.borrow();
            let password = editor.ftp_password.text().to_string();
            let asset_id = asset.id;
            button.set_sensitive(false);
            set_status(&status, &format!("● {} upload in progress…", protocol.label()), "status-neutral");

            let button_done = button.clone();
            let assets_done = assets.clone();
            let selected_done = selected.clone();
            let status_done = status.clone();
            let remote_list_done = remote_list.clone();
            let remote_items_done = remote_items.clone();
            let current_remote_path_done = current_remote_path.clone();
            let remote_path_view_done = remote_path_view.clone();
            let remote_protocol_done = remote_protocol.clone();
            run_background(
                move || {
                    upload_by_protocol(protocol, &asset, &password, &local_path, &remote_path, &item)?;
                    list_remote_by_protocol(protocol, &asset, &password, &remote_path)
                },
                move |result| {
                    button_done.set_sensitive(true);
                    let still_selected = selected_asset(&assets_done, &selected_done)
                        .map(|a| a.id == asset_id)
                        .unwrap_or(false);
                    if !still_selected || *remote_protocol_done.borrow() != protocol {
                        return;
                    }
                    match result {
                        Ok(listing) => {
                            *current_remote_path_done.borrow_mut() = listing.path.clone();
                            remote_path_view_done.set_text(&listing.path);
                            *remote_items_done.borrow_mut() = listing.items.clone();
                            rebuild_file_list(&remote_list_done, &listing.items);
                            set_status(&status_done, &format!("● {} upload complete", protocol.label()), "status-online");
                        }
                        Err(err) => set_status(&status_done, &format!("{} upload failed: {err}", protocol.label()), "status-error"),
                    }
                },
            );
        });
    }

    {
        let assets = assets.clone();
        let selected = selected.clone();
        let status = status.clone();
        let local_list = local_list.clone();
        let remote_list = remote_list.clone();
        let local_items = local_items.clone();
        let remote_items = remote_items.clone();
        let current_local_path = current_local_path.clone();
        let current_remote_path = current_remote_path.clone();
        let remote_protocol = remote_protocol.clone();
        let editor = editor.clone();
        download_btn.connect_clicked(move |button| {
            let Some(row) = remote_list.selected_row() else {
                set_status(&status, "Select a remote file or folder to download", "status-error");
                return;
            };
            let item = { remote_items.borrow().get(row.index() as usize).cloned() };
            let Some(item) = item else { return; };
            let Some(asset) = current_asset_from_editor(&assets, &selected, &editor) else {
                set_status(&status, "Select an asset first", "status-error");
                return;
            };
            let local_path = current_local_path.borrow().clone();
            let remote_path = current_remote_path.borrow().clone();
            let protocol = *remote_protocol.borrow();
            let password = editor.ftp_password.text().to_string();
            let asset_id = asset.id;
            button.set_sensitive(false);
            set_status(&status, &format!("● {} download in progress…", protocol.label()), "status-neutral");

            let button_done = button.clone();
            let assets_done = assets.clone();
            let selected_done = selected.clone();
            let status_done = status.clone();
            let local_list_done = local_list.clone();
            let local_items_done = local_items.clone();
            let remote_protocol_done = remote_protocol.clone();
            let local_path_work = local_path.clone();
            run_background(
                move || download_by_protocol(protocol, &asset, &password, &local_path_work, &remote_path, &item),
                move |result| {
                    button_done.set_sensitive(true);
                    let still_selected = selected_asset(&assets_done, &selected_done)
                        .map(|a| a.id == asset_id)
                        .unwrap_or(false);
                    if !still_selected || *remote_protocol_done.borrow() != protocol {
                        return;
                    }
                    match result {
                        Ok(()) => match list_local(&local_path) {
                            Ok(items) => {
                                *local_items_done.borrow_mut() = items.clone();
                                rebuild_file_list(&local_list_done, &items);
                                set_status(&status_done, &format!("● {} download complete", protocol.label()), "status-online");
                            }
                            Err(err) => set_status(&status_done, &format!("Downloaded, local refresh failed: {err}"), "status-error"),
                        },
                        Err(err) => set_status(&status_done, &format!("{} download failed: {err}", protocol.label()), "status-error"),
                    }
                },
            );
        });
    }

    // SSH terminal.
    {
        let assets = assets.clone();
        let selected = selected.clone();
        let terminal = terminal.clone();
        let terminal_busy = terminal_busy.clone();
        let terminal_header = terminal_header.clone();
        let status = status.clone();
        let editor = editor.clone();
        ssh_connect.connect_clicked(move |_| {
            let Some(asset) = current_asset_from_editor(&assets, &selected, &editor) else {
                set_status(&status, "Select an asset first", "status-error");
                return;
            };
            if asset.host.trim().is_empty() {
                set_status(&status, "Set the asset Host / IP first", "status-error");
                return;
            }
            let Some(ssh) = find_program(&["ssh"]) else {
                set_status(
                    &status,
                    "OpenSSH client not found. Native Arch development: sudo pacman -S openssh",
                    "status-error",
                );
                return;
            };
            let argv = vec![
                ssh.to_string_lossy().into_owned(),
                "-p".into(),
                asset.ssh_port.to_string(),
                ssh_target(&asset),
            ];
            spawn_terminal_command(
                &terminal,
                argv,
                &terminal_busy,
                &terminal_header,
                &status,
                &format!("SSH — {}", asset.name),
            );
        });
    }

    // Local shell terminal.
    {
        let terminal = terminal.clone();
        let terminal_busy = terminal_busy.clone();
        let terminal_header = terminal_header.clone();
        let status = status.clone();
        local_shell.connect_clicked(move |_| {
            let shell = std::env::var("SHELL").unwrap_or_else(|_| "/bin/bash".into());
            spawn_terminal_command(
                &terminal,
                vec![shell.clone()],
                &terminal_busy,
                &terminal_header,
                &status,
                "Local shell",
            );
        });
    }

    // Mark terminal reusable after child exits.
    {
        let terminal_busy = terminal_busy.clone();
        let status = status.clone();
        terminal.connect_child_exited(move |_, _| {
            *terminal_busy.borrow_mut() = false;
            set_status(&status, "● Terminal session ended", "status-neutral");
        });
    }

    // RDP launch.
    {
        let assets = assets.clone();
        let selected = selected.clone();
        let status = status.clone();
        let editor = editor.clone();
        rdp_connect.connect_clicked(move |_| {
            let Some(asset) = current_asset_from_editor(&assets, &selected, &editor) else {
                set_status(&status, "Select an asset first", "status-error");
                return;
            };
            let password = editor.rdp_password.text().to_string();
            match launch_rdp(&asset, &password) {
                Ok(_) => set_status(&status, "● RDP client launched", "status-online"),
                Err(err) => set_status(&status, &format!("RDP: {err}"), "status-error"),
            }
        });
    }

    // Remote shutdown: explicit confirmation, key/passwordless sudo only for now.
    {
        let window = window.clone();
        let assets = assets.clone();
        let selected = selected.clone();
        let status = status.clone();
        let editor = editor.clone();
        shutdown_btn.connect_clicked(move |_| {
            let Some(asset) = current_asset_from_editor(&assets, &selected, &editor) else {
                set_status(&status, "Select an asset first", "status-error");
                return;
            };
            if asset.host.trim().is_empty() {
                set_status(&status, "Set the asset Host / IP first", "status-error");
                return;
            }
            let Some(ssh) = find_program(&["ssh"]) else {
                set_status(&status, "OpenSSH client not found", "status-error");
                return;
            };

            let dialog = confirmation_dialog(
                &window,
                &format!("Shut down ‘{}’?", asset.name),
                "BoxHop will run ‘sudo -n systemctl poweroff’ over SSH. The remote account must be configured for key authentication/passwordless permission for this command.",
            );

            let status = status.clone();
            dialog.connect_response(move |dialog, response| {
                if response == ResponseType::Accept {
                    let result = Command::new(&ssh)
                        .arg("-p")
                        .arg(asset.ssh_port.to_string())
                        .arg("-o")
                        .arg("BatchMode=yes")
                        .arg(ssh_target(&asset))
                        .arg("sudo -n systemctl poweroff")
                        .spawn();
                    match result {
                        Ok(_) => set_status(&status, "● Shutdown command sent", "status-online"),
                        Err(err) => set_status(&status, &format!("Shutdown failed: {err}"), "status-error"),
                    }
                }
                dialog.close();
            });
            dialog.present();
        });
    }

    window.present();
}
