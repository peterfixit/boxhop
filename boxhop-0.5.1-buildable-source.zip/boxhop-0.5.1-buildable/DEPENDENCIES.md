# BoxHop dependency policy

BoxHop's final distributable is required to have **no hidden or undocumented dependencies**.

## Build-time dependencies for native source development

- Rust / Cargo
- C/C++ build toolchain (`base-devel` on Arch)
- GTK 4 development package
- VTE GTK4 development package

These are development dependencies only and are not expected on a computer that merely installs the final Flatpak.

## Current 0.5.0 native-development runtime helpers

- **OpenSSH** (`ssh`, `sftp`)
  - embedded SSH terminal launcher
  - SFTP dual-pane browser
  - SSH connection/authentication test
  - remote shutdown
- **FreeRDP 3** (`wlfreerdp3`, `sdl-freerdp3`, `xfreerdp3` or compatible `xfreerdp`)
  - RDP launch
  - RDP authentication test
- **GnuPG** (`gpg`)
  - AES-256 credential-vault key wrapping and encrypted per-asset password blobs

The persistent runtime/crash logger is implemented with the Rust standard library and existing GLib/GTK code and adds no host runtime dependency.

The **FTP backend is in-process Rust code**. FTP login testing, directory listing, passive data connections, upload and download do not require a host FTP client or curl.

On Arch:

```bash
sudo pacman -S --needed openssh freerdp gnupg
```

These helpers are **not allowed** to remain undeclared host requirements in the final Flatpak.


## 0.5.0 size/efficiency notes

- The release Rust binary is built with `opt-level = "s"`, full LTO, one codegen unit and stripped symbols.
- FTP is already implemented in-process and does not add a runtime helper.
- FTP downloads stream to disk, so downloading a multi-gigabyte file no longer requires a multi-gigabyte RAM buffer.
- The final app should prefer in-process crypto for the credential vault if it can be migrated safely; that can remove the GnuPG runtime helper and reduce packaging complexity.
- OpenSSH is currently retained because it provides mature terminal/SFTP behaviour. Replacing it only makes sense if an in-process SSH backend can preserve interactive PTY, host-key and agent behaviour without regressions.
- FreeRDP is currently the pragmatic RDP engine. Replacing it purely for language uniformity is not recommended before 1.0.

## Credential-vault cryptography

BoxHop adapts the Boop Crypt separation between a user password and a random encryption key:

- random vault key: 64 bytes from `/dev/urandom`, represented as 128 hexadecimal characters;
- master-password wrapper: GnuPG symmetric AES-256;
- wrapper S2K mode: iterated+salted mode 3;
- wrapper S2K digest: SHA-512;
- wrapper S2K count: `65011712`;
- per-asset encrypted credential blob: GnuPG symmetric AES-256;
- per-asset S2K mode: iterated+salted mode 3;
- per-asset S2K digest: SHA-512;
- per-asset S2K count: `1048576`;
- GnuPG internal compression is disabled;
- master password is never persisted;
- config/credential directories use mode 0700 and credential/config files use mode 0600.

## Final Flatpak rule

Before a release is labelled final:

1. Rust crates must be pinned and vendored or represented by fully pinned Flatpak sources.
2. OpenSSH/SFTP, FreeRDP and GnuPG must be bundled inside `/app`, or replaced by linked/in-process implementations.
3. Every Flatpak permission must be declared in the manifest.
4. `DEPENDENCIES.md` must list every bundled library/tool and its licence.
5. The produced `.flatpak` must be installed and tested in a clean VM with no development packages, OpenSSH client, FreeRDP client, GnuPG, curl, FTP client or other undeclared helper installed on the host.
6. If the clean-VM test requires a manual host package beyond Flatpak itself and the declared Flatpak runtime, the release fails the dependency test.

## Not implemented yet

- FTPS/TLS.
- Password-fed interactive SSH/SFTP sessions; current VTE/SFTP paths still use normal OpenSSH interaction/key-agent behavior.
- Bundled OpenSSH/FreeRDP/GnuPG Flatpak modules.
- Fully offline/pinned Rust dependency source set.
