#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

# Make the bundled development icon visible to GTK without installing it system-wide.
export XDG_DATA_DIRS="$ROOT/data${XDG_DATA_DIRS:+:$XDG_DATA_DIRS}"

if ! command -v cargo >/dev/null 2>&1; then
  echo "[ERROR] cargo is not installed."
  echo "Arch: sudo pacman -S --needed base-devel rust gtk4 vte4 openssh freerdp gnupg"
  exit 1
fi

if ! command -v pkg-config >/dev/null 2>&1 || ! pkg-config --exists gtk4 vte-2.91-gtk4; then
  echo "[ERROR] GTK4/VTE4 development files are missing."
  echo "Arch: sudo pacman -S --needed base-devel rust gtk4 vte4 openssh freerdp gnupg"
  exit 1
fi

if ! command -v ssh >/dev/null 2>&1 || ! command -v sftp >/dev/null 2>&1; then
  echo "[WARN] OpenSSH client tools not found. SSH/SFTP controls will be unavailable."
  echo "       Arch: sudo pacman -S --needed openssh"
fi

if ! command -v wlfreerdp3 >/dev/null 2>&1 \
   && ! command -v sdl-freerdp3 >/dev/null 2>&1 \
   && ! command -v xfreerdp3 >/dev/null 2>&1 \
   && ! command -v xfreerdp >/dev/null 2>&1; then
  echo "[WARN] FreeRDP client not found. RDP launch/auth tests will be unavailable."
  echo "       Arch: sudo pacman -S --needed freerdp"
fi

if ! command -v gpg >/dev/null 2>&1; then
  echo "[WARN] GnuPG not found. Encrypted credential-vault functions will be unavailable."
  echo "       Arch: sudo pacman -S --needed gnupg"
fi

exec cargo run
