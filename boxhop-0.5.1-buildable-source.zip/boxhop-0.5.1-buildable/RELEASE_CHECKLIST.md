# BoxHop release checklist

## Must be complete before 1.0

- [ ] Build and install on a clean Arch/Fedora/Debian VM using only Flatpak plus the declared runtime.
- [ ] Bundle or replace OpenSSH, FreeRDP and GnuPG so there are no host-only runtime helpers.
- [ ] Pin Rust dependencies with a committed `Cargo.lock` and fully reproducible Flatpak sources.
- [ ] Add transfer progress, cancel and clear error reporting for long uploads/downloads.
- [ ] Add overwrite confirmation and safe partial-file handling for every transfer backend.
- [ ] Add explicit SSH host-key fingerprint verification rather than hiding first-use trust behind OpenSSH defaults.
- [ ] Add FTPS only if plain FTP must remain; recommend SFTP where possible.
- [ ] Test large files (>10 GiB), deep recursive trees, Unicode names, spaces and interrupted transfers.
- [ ] Test IPv4/IPv6, DNS names and unavailable hosts.
- [ ] Test RDP on Wayland and X11.
- [ ] Test Wake-on-LAN across the intended subnets/VLANs.
- [ ] Verify crash logs never contain passwords, vault keys or FreeRDP password arguments.
- [ ] Run `cargo clippy --release -- -D warnings` and `cargo fmt --check`.
- [ ] Run `scripts/size-report.sh` and record final app/bundle/runtime sizes.
- [ ] Validate AppStream metadata and desktop integration.

## High-value additions

1. Transfer queue with progress, speed, ETA, pause/cancel and retry.
2. Drag-and-drop between local and remote panes.
3. Search/filter in both panes and in the asset list.
4. Per-asset protocol enable/disable switches so unused FTP/RDP fields disappear.
5. SSH host-key fingerprint UI and known-host management.
6. Quick actions on asset rows: terminal, files, RDP, wake, shutdown.
7. Import/export encrypted asset profiles for backup or moving BoxHop to another machine.
8. Keyboard shortcuts and command palette.
9. Optional LAN discovery for SSH/RDP hosts, disabled by default.
10. A diagnostics export that packages logs and non-secret configuration for bug reports.

## Nice-to-have after 1.0

- Multiple terminal tabs per asset.
- Bookmarked remote paths.
- File rename/new-folder/delete actions.
- Transfer resume where the remote protocol supports it.
- Optional system theme mode in addition to BoxHop dark mode.
