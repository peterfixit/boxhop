#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

command -v flatpak-builder >/dev/null || {
  echo "[ERROR] flatpak-builder is not installed"
  exit 1
}

rm -rf build-dir
flatpak-builder --user --install --force-clean build-dir packaging/io.pmhs.boxhop.yml

echo "[OK] BoxHop installed as io.pmhs.boxhop"
