#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "BoxHop size report"
echo "=================="
echo "Source tree: $(du -sh . | awk '{print $1}')"
echo "Icons:      $(du -sh data/icons | awk '{print $1}')"

if command -v cargo >/dev/null 2>&1; then
  echo
  echo "Building optimized release binary..."
  cargo build --release
  if [[ -f target/release/boxhop ]]; then
    echo "Release binary: $(du -h target/release/boxhop | awk '{print $1}')"
    command -v size >/dev/null 2>&1 && size target/release/boxhop || true
  fi
else
  echo "Cargo not installed; release binary size not measured."
fi

if [[ -d build-dir ]]; then
  echo "Flatpak build-dir: $(du -sh build-dir | awk '{print $1}')"
else
  echo "Flatpak build-dir: not present"
fi
